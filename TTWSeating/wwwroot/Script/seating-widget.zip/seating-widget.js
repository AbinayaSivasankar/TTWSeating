﻿
let dotNetHelper;
var globalPriceList = [];
let undoStack = [];
let redoStack = [];
let isLoading = false;
let isBulkAdding = false;
let previewseats = [];
let segmentActive = false;
let startX = 0;
let startY = 0;
let direction = null;
let lastDirection = null;
let segmentPath = [];
const seatSize = 18;
const seatGap = 6;
const rowGap = 30;
let canvas;
let segmentRowPreviewMode = false;
let segmentRowFinalized = false;
let segmentRowPath = [];
let rowSelectionGuides = {
    start: null,
    end: null,
    top: null,
    bottom: null
};
let previewLocked = false;
let currentRowPreview = [];
let previewRow = null;
let finalRows = [];
let dragDirection = null;
const directionThreshold = 10;
let guideLine = null;
let crossGuideLine = null;
let rowBaseline = null;
let lastRowPosition = null;

window.fabricInterop = {
    canvases: {},
    isDrawingSeats: false,
    mode: "select",
    seatSpacing: 22,
    seatCounter: 1,
    lastSeat: null,
    alignmentMode: null,
    guideLine: null,
    rowDirection: "horizontal",
    previewLine: null,
    rowIndex: 1,
    rowSeatCount: 0,
    isDrawingRow: false,
    rowStart: null,
    previewSeats: [],
    previewLines: {
        start: null,
        end: null,
        top: null,
        bottom: null
    },
    alignmentGuides: {
        start: null,
        end: null
    },
    hoverStartGuide: null,
    lastHoverPoint: null,
    rowHoverGuide: null,
    isDrawingMultipleRows: false,
    firstRowSeatCount: 0,
    firstRowDirection: null,
    firstRowStart: null,
    firstRowLength: 0,
    rowGap: 30,
    multiRowActive: false,
    generatedRows: [],
    lastRowY: null,
    isDrawingFirstRow: false,
    straightLineGuide: null,
    snapThreshold: 6,
    dragGuides: {
        start: null,
        end: null,
        active: false
    },
    multiRowStartPoint: null,
    multiRowCurrentPoint: null,
    multiRowDirection: null,
    multiRowAngle: 0,
    multiRowSpacing: 30,
    multiRowPreviewRows: [],
    firstRowBaseX: null,
    firstRowBaseY: null,
    lastRowX: null,
  

    initCanvas(canvasId) {
        canvas = new fabric.Canvas(canvasId, {
            selection: true,
            width: document.getElementById(canvasId).parentElement.clientWidth,
            height: document.getElementById(canvasId).parentElement.clientHeight
        });
        this.canvasWidth = canvas.width;
        this.canvasHeight = canvas.height;
        undoStack.push(JSON.stringify(canvas.toJSON()));
        this.canvases[canvasId] = canvas;
        this.isFirstRowFinalized = false;
        // Seat creation
        canvas.on("mouse:down", (opt) => {
            if (this.mode !== "create") return;
            this.isDrawingSeats = true;
            this.alignmentMode = null;
            const pointer = canvas.getPointer(opt.e);
            this.addSeat(canvasId, pointer.x, pointer.y);
        });

        canvas.on("mouse:move", (opt) => {
            if (this.mode !== "create") return;
            const pointer = canvas.getPointer(opt.e);
            let x = pointer.x;
            let y = pointer.y;
            if (this.lastSeat) {
                if (!this.alignmentMode) {
                    const dx = Math.abs(pointer.x - this.lastSeat.x);
                    const dy = Math.abs(pointer.y - this.lastSeat.y);
                    this.alignmentMode = dx > dy ? "horizontal" : "vertical";
                }
                if (this.alignmentMode === "horizontal") y = this.lastSeat.y;
                else x = this.lastSeat.x;
            }
            if (this.isDrawingSeats && (!this.lastSeat || Math.hypot(x - this.lastSeat.x, y - this.lastSeat.y) > this.seatSpacing)) {
                this.addSeat(canvasId, x, y);
            }
        });

        canvas.on("mouse:up", () => {
            this.isDrawingSeats = false;
            this.alignmentMode = null;
        });

        // Rectangle creation
        canvas.on("mouse:down", (opt) => {
            if (this.mode !== "rectangle") return;
            const pointer = canvas.getPointer(opt.e);
            this.isDrawingRect = true;
            this.rectStartX = pointer.x;
            this.rectStartY = pointer.y;
            this.activeRect = new fabric.Rect({
                left: this.rectStartX,
                top: this.rectStartY,
                width: 1,
                height: 1,
                fill: "rgba(0,0,0,0.1)",
                stroke: "black",
                strokeWidth: 1,
                selectable: false,
                objectType: 'rectangle',
                createdBy: 'rectangleTool',
                rectangleId: `rect-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
            });
            canvas.add(this.activeRect);
        });

        canvas.on("mouse:move", (opt) => {
            if (this.mode !== "rectangle" || !this.isDrawingRect) return;
            const pointer = canvas.getPointer(opt.e);
            const width = pointer.x - this.rectStartX;
            const height = pointer.y - this.rectStartY;
            this.activeRect.set({
                width: Math.abs(width),
                height: Math.abs(height),
                left: width < 0 ? pointer.x : this.rectStartX,
                top: height < 0 ? pointer.y : this.rectStartY
            });
            canvas.renderAll();
        });

        canvas.on("mouse:up", () => {
            if (this.mode !== "rectangle") return;
            this.isDrawingRect = false;
            this.setMode(this.mode);
            if (this.activeRect) {
                this.activeRect.set({
                    selectable: true,
                    hasControls: true,
                    hasBorders: true,
                    lockUniScaling: false
                });
                canvas.renderAll();
                if (canvas.getObjects().length > 0) {
                    saveState(canvas);
                } else {
                    undoStack.push(JSON.stringify(canvas.toJSON()));
                    redoStack = [];
                }
                this.activeRect = null;
            }
        });

        // General Category Rect
        canvas.on("mouse:down", (opt) => {
            if (this.mode !== "general") return;
            const pointer = canvas.getPointer(opt.e);
            this.isDrawingRect = true;
            this.rectStartX = pointer.x;
            this.rectStartY = pointer.y;
            this.activeRect = new fabric.Rect({
                left: this.rectStartX,
                top: this.rectStartY,
                width: 1,
                height: 1,
                fill: "rgba(0,0,0,0.1)",
                stroke: "black",
                strokeWidth: 1,
                selectable: false,
                objectType: 'genrectangle',
                createdBy: 'rectangleTool',
                rectangleId: `rect-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
            });
            canvas.add(this.activeRect);
        });

        canvas.on("mouse:move", (opt) => {
            if (this.mode !== "general" || !this.isDrawingRect) return;
            const pointer = canvas.getPointer(opt.e);
            const width = pointer.x - this.rectStartX;
            const height = pointer.y - this.rectStartY;
            this.activeRect.set({
                width: Math.abs(width),
                height: Math.abs(height),
                left: width < 0 ? pointer.x : this.rectStartX,
                top: height < 0 ? pointer.y : this.rectStartY
            });
            canvas.renderAll();
        });

        canvas.on("mouse:up", () => {
            if (this.mode !== "general") return;
            this.isDrawingRect = false;
            this.setMode(this.mode);
            if (this.activeRect) {
                this.activeRect.set({
                    selectable: true,
                    hasControls: true,
                    hasBorders: true,
                    lockUniScaling: false
                });
                canvas.renderAll();
                if (canvas.getObjects().length > 0) {
                    saveState(canvas);
                } else {
                    undoStack.push(JSON.stringify(canvas.toJSON()));
                    redoStack = [];
                }
                this.activeRect = null;
            }
        });

        // Row creation
        canvas.on("mouse:down", (opt) => {
            if (this.mode !== "row") return;
            const pointer = canvas.getPointer(opt.e);
            this.rowStart = this.getSnappedRowStart(pointer);
            const hit = opt.target;
            if (hit && hit.objectType === "rectangle") {
                this.isDrawingRow = false;
                return;
            }
            this.rowDirection = null;
            this.isDrawingRow = true;
            this.rowAngle = 0;
            if (this.hoverStartGuide) {
                canvas.remove(this.hoverStartGuide);
                this.hoverStartGuide = null;
            }
        });

        canvas.on("mouse:move", (opt) => {
            if (!this.isDrawingRow || this.mode !== "row") return;
            const canvas = this.canvases[canvasId];
            const hit = canvas.findTarget(opt.e, true);
            if (hit && hit.objectType === "rectangle") return;
            const pointer = canvas.getPointer(opt.e);
            this.previewSeats.forEach(s => canvas.remove(s));
            this.previewSeats = [];
            if (this.previewLine) {
                canvas.remove(this.previewLine);
                this.previewLine = null;
            }
            if (this.straightLineGuide) {
                canvas.remove(this.straightLineGuide);
                this.straightLineGuide = null;
            }
            const dx = pointer.x - this.rowStart.x;
            const dy = pointer.y - this.rowStart.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            const spacing = this.seatSpacing || 20;
            if (distance < 5) {
                canvas.renderAll();
                return;
            }
            let angle = Math.atan2(dy, dx) * (180 / Math.PI);
            const snappedAngle = this.snapToStraightLine(angle);
            const isSnapped = snappedAngle !== angle;
            if (isSnapped) {
                angle = snappedAngle;
                this.showStraightLineGuide(canvas, this.rowStart, angle);
            }
            this.rowAngle = angle;
            const seatCount = Math.max(2, Math.floor(distance / spacing) + 1);
            const rowLength = (seatCount - 1) * spacing;
            const endX = this.rowStart.x + Math.cos(angle * Math.PI / 180) * rowLength;
            const endY = this.rowStart.y + Math.sin(angle * Math.PI / 180) * rowLength;
            const lineColor = isSnapped ? "#4CAF50" : "#2196F3";
            const lineDash = isSnapped ? [] : [5, 5];
            this.previewLine = new fabric.Line(
                [this.rowStart.x, this.rowStart.y, endX, endY],
                {
                    stroke: lineColor,
                    strokeDashArray: lineDash,
                    selectable: false,
                    evented: false,
                    strokeWidth: 2
                }
            );
            canvas.add(this.previewLine);
            for (let i = 0; i < seatCount; i++) {
                const seatDistance = i * spacing;
                const x = this.rowStart.x + Math.cos(angle * Math.PI / 180) * seatDistance;
                const y = this.rowStart.y + Math.sin(angle * Math.PI / 180) * seatDistance;
                const seat = new fabric.Circle({
                    left: x,
                    top: y,
                    radius: 8,
                    fill: "white",
                    originX: "center",
                    originY: "center",
                    selectable: false,
                    evented: false,
                    stroke: "black",
                    strokeWidth: 1
                });
                seat.seatLabel = i + 1;
                seat.isPreview = true;
                this.previewSeats.push(seat);
                canvas.add(seat);
            }
            this.updateAngledRowGuides(canvas, this.rowStart, angle, seatCount);
            const tooltip = document.getElementById("seatTooltip");
            if (tooltip) {
                setTimeout(() => {
                    tooltip.textContent = `${seatCount} seats`;
                    tooltip.style.left = (opt.e.clientX + 10) + "px";
                    tooltip.style.top = (opt.e.clientY + 10) + "px";
                    tooltip.style.display = "block";
                }, 0);
            }
            canvas.renderAll();
        });

        canvas.on("mouse:move", (opt) => {
            if (this.mode !== "row" && this.mode !== "multiRow" && this.mode !== "segmentRow" || (this.mode === "multiRow" && this.firstRowSeatCount !== 0)) return;
            if (this.isDrawingRow) return;
            const canvas = this.canvases[canvasId];
            const pointer = canvas.getPointer(opt.e);
            let direction = "horizontal";
            if (this.lastHoverPoint) {
                const dx = Math.abs(pointer.x - this.lastHoverPoint.x);
                const dy = Math.abs(pointer.y - this.lastHoverPoint.y);
                direction = dx > dy ? "horizontal" : "vertical";
            }
            this.lastHoverPoint = pointer;
            this.updateRowHoverGuide(canvas, direction);
            this.updateHoverStartGuide(canvas, pointer, direction);
            canvas.renderAll();
        });

        canvas.on("mouse:up", () => {
            if (!this.isDrawingRow || this.mode !== "row") return;
            const canvas = this.canvases[canvasId];
            if (this.straightLineGuide) {
                canvas.remove(this.straightLineGuide);
                this.straightLineGuide = null;
            }
            if (!this.previewSeats || this.previewSeats.length === 0) {
                this.isDrawingRow = false;
                return;
            }
            const spacing = this.seatSpacing || 20;
            const seatCount = this.previewSeats.length;
            if (seatCount === 0) return;
            const rowLabel = "";
            const rowId = `row-${rowLabel}-${Date.now()}`;
            isBulkAdding = true;
            const angle = this.rowAngle;
            for (let i = 0; i < seatCount; i++) {
                const previewSeat = this.previewSeats[i];
                if (!previewSeat) continue;
                const x = previewSeat.left;
                const y = previewSeat.top;
                const seatLabel = (i + 1).toString();
                const seatId = rowLabel ? `${rowLabel}${seatLabel}` : `Seat-${this.seatCounter++}`;
                this.createSeat(canvas, x, y, seatLabel, seatId, rowLabel, rowId);
            }
            this.previewSeats.forEach(seat => {
                canvas.remove(seat);
                if (seat.seatText) {
                    canvas.remove(seat.seatText);
                }
            });
            this.previewSeats = [];
            if (this.previewLine) {
                canvas.remove(this.previewLine);
                this.previewLine = null;
            }
            this.lastRowPosition = {
                angle: angle,
                x: this.rowStart.x,
                y: this.rowStart.y,
                seatCount: seatCount
            };
            if (!this.rowBaseline) {
                this.rowBaseline = { ...this.lastRowPosition };
            }
            this.isDrawingRow = false;
            this.clearAlignmentGuides(canvas);
            this.clearRowGuide(canvas);
            const tooltip = document.getElementById("seatTooltip");
            if (tooltip) {
                tooltip.style.display = "none";
            }
            canvas.renderAll();
            isBulkAdding = false;
            this.setMode(this.mode);
            setTimeout(() => {
                if (canvas.getObjects().length > 0) {
                    saveState(canvas);
                } else {
                    undoStack.push(JSON.stringify(canvas.toJSON()));
                    redoStack = [];
                }
            }, 100);
        });

        const tooltip = document.getElementById("seatTooltip");

        canvas.on("mouse:move", (opt) => {
            const pointer = canvas.getPointer(opt.e);
            const target = canvas.findTarget(opt.e, true);
            if (target && target.seatLabel) {
                tooltip.innerText = target.seatLabel;
                tooltip.style.display = "block";
                tooltip.style.left = opt.e.pageX + 10 + "px";
                tooltip.style.top = opt.e.pageY + 10 + "px";
            } else {
                tooltip.style.display = "none";
            }
        });

        canvas.on('selection:created', (e) => {
            if (this.mode === "select") {
                var ddlcolor = document.getElementById("ddlcolor");
                if (ddlcolor) {
                    document.getElementById("ddlcolor").value = "";
                }
                this.handleRowSelection(canvas, e);
                this.handleSelectionChanged(canvasId, e);
            }
        });

        canvas.on('selection:updated', (e) => {
            if (this.mode === "select") {
                this.handleRowSelection(canvas, e);
                this.handleSelectionChanged(canvasId, e);
            }
        });

        canvas.on('selection:cleared', () => {
            if (this.mode === "select") {
                this.handleSelectionCleared(canvasId);
            }
        });

        // Multi row creation - UPDATED FOR ALL DIRECTIONS
        
        canvas.on("mouse:down", (opt) => {
            if (this.mode !== "multiRow") return;

            const pointer = canvas.getPointer(opt.e);

            // START FIRST ROW DRAW
            if (!this.isFirstRowFinalized) {
                const hit = canvas.findTarget(opt.e, true);
                if (hit && hit.objectType === "rectangle") {
                    this.isDrawingFirstRow = false;
                    return;
                }

                this.multiRowStartPoint = { x: pointer.x, y: pointer.y };
                this.rowStart = this.getSnappedRowStart(pointer);

                this.isDrawingFirstRow = true;
                this.firstRowSeatCount = 0;
                this.rowAngle = 0;
                this.multiRowDirection = null;

                this.clearAllPreviews(canvas);
                return;
            }

            // START MULTI ROW DRAG (ONLY AFTER FIRST ROW FINALIZED)
            if (this.isFirstRowFinalized) {
                this.multiRowActive = true;
                this.multiRowStartPoint = { x: pointer.x, y: pointer.y };

                this.firstRowBaseX = this.firstRowStartX;
                this.firstRowBaseY = this.firstRowStartY;
            }
        });
      
        canvas.on("mouse:move", (opt) => {

            const canvas = this.canvases[canvasId];

            // ✅ FIXED: removed firstRowSeatCount === 0
            if (this.mode === "multiRow" && this.isDrawingFirstRow) {
                const pointer = canvas.getPointer(opt.e);
                this.updateMultiRowFirstRowPreview(canvas, pointer, opt);
                return;
            }

            if (this.mode === "multiRow" && this.multiRowActive && this.firstRowSeatCount > 0) {
                const pointer = canvas.getPointer(opt.e);
                this.updateMultiRowPreviewAllDirections(canvas, pointer, opt);
                return;
            }
        });
       
        canvas.on("mouse:up", (opt) => {
            const canvas = this.canvases[canvasId];

            // FINISH FIRST ROW
            if (this.mode === "multiRow" && this.isDrawingFirstRow && this.firstRowSeatCount > 0) {

                this.isDrawingFirstRow = false;
                this.isFirstRowFinalized = true;

                this.firstRowStartX = this.rowStart.x;
                this.firstRowStartY = this.rowStart.y;
                this.firstRowBaseX = this.rowStart.x;
                this.firstRowBaseY = this.rowStart.y;

                this.firstRowAngle = this.rowAngle;

                if (this.straightLineGuide) {
                    canvas.remove(this.straightLineGuide);
                    this.straightLineGuide = null;
                }

                this.createActualRowFromPreview(canvas);
                this.clearAllPreviews(canvas);
                return;
            }

            // FINISH MULTI ROW
            if (this.mode === "multiRow" && this.multiRowActive) {

                this.multiRowActive = false;

                this.createActualRowsFromPreviewsAllDirections(canvas);
                this.clearAllPreviews(canvas);
                this.clearGeneratedRows(canvas);

                // RESET EVERYTHING
                this.firstRowSeatCount = 0;
                this.firstRowAngle = 0;
                this.firstRowStartX = null;
                this.firstRowStartY = null;
                this.firstRowBaseX = null;
                this.firstRowBaseY = null;

                this.multiRowStartPoint = null;
                this.multiRowCurrentPoint = null;
                this.multiRowDirection = null;
                this.multiRowPreviewRows = [];

                this.isFirstRowFinalized = false; // IMPORTANT RESET

                return;
            }
        });


        // Segment row creation
        canvas.on("mouse:down", (opt) => {
            if (this.mode !== "segmentRow") return;
            const p = canvas.getPointer(opt.e);
            startX = p.x;
            startY = p.y;
            dragDirection = null;
            segmentActive = true;
        });

        canvas.on("mouse:move", (opt) => {
            if (!segmentActive || this.mode !== "segmentRow") return;
            const p = canvas.getPointer(opt.e);
            const dx = p.x - startX;
            const dy = p.y - startY;
            const absDx = Math.abs(dx);
            const absDy = Math.abs(dy);
            if (absDx < 5 && absDy < 5) return;
            if (!dragDirection) {
                if (absDx > directionThreshold || absDy > directionThreshold) {
                    dragDirection = absDx > absDy ? "horizontal" : "vertical";
                } else {
                    return;
                }
            }
            currentRowPreview.forEach(s => {
                if (canvas.contains(s)) {
                    canvas.remove(s);
                }
            });
            currentRowPreview = [];
            drawGuideLines(dragDirection, dx, dy);
            createDynamicPreview(dx, dy, true, dragDirection);
        });

        canvas.on("mouse:up", () => {
            if (this.mode !== "segmentRow") return;
            segmentActive = false;
            previewseats = previewseats.concat(currentRowPreview);
            currentRowPreview.forEach(obj => {
                previewseats.push(obj);
            });
            currentRowPreview = [];
            if (guideLine && canvas.contains(guideLine)) {
                canvas.remove(guideLine);
            }
            if (crossGuideLine && canvas.contains(crossGuideLine)) {
                canvas.remove(crossGuideLine);
            }
            guideLine = null;
            crossGuideLine = null;
        });

        canvas.on("mouse:dblclick", () => {
            if (this.mode !== "segmentRow") return;
            if (previewseats.length === 0) return;
            finalizeSegment();
        });

        canvas.on('object:moving', (opt) => {
            if (this.mode !== "select") return;
            const target = opt.target;
            if (!target) return;
            if (target.type !== 'activeSelection' && target.type !== 'group') return;
            const bounds = target.getBoundingRect(true);
            const seatRadius = 8;
            const firstCenterX = bounds.left + seatRadius;
            const lastCenterX = bounds.left + bounds.width - seatRadius;
            this.updateDragGuides(canvas, firstCenterX, lastCenterX);
        });

        canvas.on('object:modified', () => {
            this.clearDragGuides(canvas);
        });

        canvas.on('selection:cleared', () => {
            this.clearDragGuides(canvas);
        });

        canvas.on('mouse:wheel', function (opt) {
            let delta = opt.e.deltaY;
            let zoom = canvas.getZoom();
            zoom *= 0.999 ** delta;
            if (zoom > 3) zoom = 3;
            if (zoom < 0.5) zoom = 0.5;
            canvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom);
            opt.e.preventDefault();
            opt.e.stopPropagation();
        });
       
        //canvas.on('mouse:down', (opt) => {
        //    if (this.mode !== "select") return;
        //    if (!opt.target) return;
        //    const clicked = opt.target;
        //    if (clicked.type === "group" && clicked.seatId) {
        //        const rowId = clicked.rowId;
        //        if (!rowId) return;
        //        const rowSeats = canvas.getObjects().filter(obj =>
        //            obj.type === "group" && obj.rowId === rowId && obj.seatId
        //        );
        //        if (rowSeats.length === 0) return;
        //        const selection = new fabric.ActiveSelection(rowSeats, { canvas });
        //        canvas.setActiveObject(selection);
        //        canvas.requestRenderAll();
        //    }
        //});
    },

    enableAdminMode(canvasId) {
        this.mode = 'admin';
        const canvas = this.canvases[canvasId];
        canvas.selection = false;
        canvas.forEachObject(o => {
            o.selectable = false; o.evented = false;
        });
    },

    enableUserMode(canvasId, Seatdetails, ChartId) {
        const canvas = this.canvases[canvasId];
        var seats = "";
        this.mode = "user";
        this.isDrawingSeats = false;
        canvas.selection = false;
        canvas.off("mouse:move");
        canvas.off("mouse:down");
        canvas.off("mouse:up");
        if (!canvas.selectedSeats) {
            canvas.selectedSeats = [];
        } else {
            canvas.selectedSeats = [];
        }
        this.applyStatusColors(canvasId, Seatdetails);
        canvas.forEachObject(obj => {
            obj.selectable = false;
            obj.evented = true;
            obj.lockMovementX = true;
            obj.lockMovementY = true;
            obj.hasControls = false;
            obj.hoverCursor = 'pointer';
            if (typeof obj.isSelected === 'undefined') {
                obj.isSelected = false;
            }
            let textChild = null;
            if (obj.textObj) textChild = obj.textObj;
            if (!textChild && obj._objects && obj._objects.length) {
                textChild = obj._objects.find(ch => (ch.type === 'text' || ch.type === 'i-text' || ch.type === 'textbox'));
            }
            if (textChild) {
                if (typeof obj.originalLabel === 'undefined') {
                    obj.originalLabel = textChild.text || '';
                }
                textChild.set('text', '');
                obj.textObj = textChild;
            }
        });
        canvas.renderAll();

        canvas.on("mouse:over", function (opt) {
            if (!opt.target || opt.target.type !== "group") return;
            let seat = opt.target;
            const seatStatus = seat.seatStatus || seat.get('seatStatus') || 'available';
            if (seatStatus == "sold") return;
            let categoryId = seat.categoryName || seat.get("categoryName") || "";
            let priceObj = window.globalPriceList.find(x => x.category === categoryId);
            let price = priceObj ? priceObj.price : "Unknown";
            showTooltip(opt.e.clientX, opt.e.clientY,
                `Category : ${categoryId}<br>Seat : ${seat.seatId}<br>Price : $${price}`);
        });

        canvas.on("mouse:out", function () {
            hideTooltip();
        });

        canvas.on("mouse:down", (opt) => {
            debugger;
            if (!opt.target) return;
            let seat = opt.target;
            if (seat.type === 'group') {
                if (seat.type !== 'group') seat = seat.group;
                if (!seat) return;
                let seatStatus = 'available';
                for (var item of Seatdetails) {
                    if (item.seat_name == seat.seatId) {
                        seatStatus = item.status;
                    }
                }
                if (seatStatus === 'sold' || seatStatus === 'booked' || seatStatus == "Reserved") {
                    return;
                }
                const textObj = seat.textObj;
                if (!textObj) return;
                let SEATID = '';
                if (seat.seatId && seat.seatId !== "") {
                    SEATID = seat.seatId;
                } else if (seat.get('seatId') && seat.get('seatId') !== "") {
                    SEATID = seat.get('seatId');
                } else if (seat.seatLabel && seat.seatLabel !== "") {
                    SEATID = "Seat-" + seat.seatLabel;
                } else if (textObj.text && textObj.text !== "" && textObj.text !== "✔") {
                    SEATID = "Seat-" + textObj.text;
                } else {
                    SEATID = "Seat-unknown";
                }
                const seatId = seat.seatId || seat.get('seatId') || '';
                if (textObj.text === "✔") {
                    textObj.set({ text: "", fontWeight: "normal", fontSize: 10 });
                    seat.set("isSelected", false);
                    seat.isSelected = false;
                    seat.set("holdToken", "");
                    const index = canvas.selectedSeats.findIndex(s => s.id === seatId);
                    if (index !== -1) {
                        canvas.selectedSeats.splice(index, 1);
                    }
                } else {
                    textObj.set({ text: "✔", fontWeight: "normal", fontSize: 12 });
                    seat.set("isSelected", true);
                    seat.isSelected = true;
                    const existingIndex = canvas.selectedSeats.findIndex(s => s.id === seatId);
                    let holdToken = generateHoldToken();
                    seat.set("holdToken", holdToken);
                    if (existingIndex === -1) {
                        canvas.selectedSeats.push({
                            id: seatId,
                            label: seat.seatLabel || seat.get('seatLabel') || '',
                            categoryId: seat.categoryId || seat.get('categoryId') || '',
                            seatType: seat.seatType || seat.get('seatType') || '',
                            x: seat.left,
                            y: seat.top,
                            holdtoken: holdToken,
                            categoryName: seat.categoryName || seat.get('categoryName') || '',
                        });
                        if (seatId != undefined) {
                            if (seats == "") {
                                seats = seatId;
                            } else {
                                seats += "," + seatId;
                            }
                        }
                    }
                    saveHoldToken(ChartId, seatId, holdToken);
                }
                var selected = canvas.selectedSeats;
                if (window.receiveSelectedSeatsFromBlazor) {
                    window.receiveSelectedSeatsFromBlazor(selected);
                }
                canvas.renderAll();
            } else if (seat.type === 'rect' && seat.objectType === 'genrectangle') {
                this.handleGenRectangleSelection(canvasId, seat, opt.e);
            }
        });
    },

    applyStatusColors(canvasId, SeatInfo) {
        const canvas = this.canvases[canvasId];
        const seats = canvas.getObjects().filter(obj => obj.type === 'group' && obj.seatId);
        seats.forEach(seat => {
            if (!seat.circle) return;
            let color;
            for (var item of SeatInfo) {
                if (item.seat_name == seat.seatId) {
                    switch (item.status) {
                        case 'sold':
                        case 'booked':
                        case 'Reserved':
                            color = "#e7e7e7";
                            break;
                        case 'selected':
                            color = "#4CAF50";
                            break;
                        case 'available':
                        default:
                            color = seat.categoryId || "#f2fd58";
                            break;
                    }
                    if (item.status == "sold" || item.status == "booked" || item.status == "Reserved") {
                        seat.set('hoverCursor', 'default');
                    } else {
                        seat.set('hoverCursor', 'pointer');
                    }
                    if (seat.circle) {
                        if (item.status == "sold" || item.status == "booked") {
                            seat.circle.set('hoverCursor', 'default');
                        } else {
                            seat.circle.set('hoverCursor', 'pointer');
                        }
                    }
                    seat.circle.set('fill', color);
                    seat.circle.set('stroke', color);
                    seat.circle.set('dirty', true);
                }
            }
        });
        canvas.renderAll();
    },

    enableSelectMode(canvasId) {
        this.disableRowCreateMode(canvasId);
        resetSegmentRowState();
        const canvas = this.canvases[canvasId];
        this.clearRowGuide(canvas);
        clearPreview();
        this.mode = "select";
        this.setMode("select");
        this.isDrawingSeats = false;
        canvas.selection = true;
        canvas.forEachObject(o => o.selectable = true);
        saveState(canvas);
        canvas.on("mouse:dblclick", function (opt) {
            if (!opt.target || opt.target.type !== "group") return;
            const rowId = opt.target.rowId;
            if (!rowId) return;
            const seats = canvas.getObjects().filter(o => o.type === "group" && o.rowId === rowId);
            const sel = new fabric.ActiveSelection(seats, { canvas });
            sel.borderColor = "rgb(7, 132, 250)";
            sel.cornerColor = "rgb(7, 132, 250)";
            sel.cornerStrokeColor = "#ffffff";
            canvas.setActiveObject(sel);
            canvas.renderAll();
        });

        this.showValidation(canvas);
    },

    handleRowSelection(canvas, opt) {
        if (!opt.selected || opt.selected.length === 0) return;
        const selected = opt.selected;
        const selectedRowIds = new Set();
        selected.forEach(obj => {
            if (obj.type === "group" && obj.rowId) {
                selectedRowIds.add(obj.rowId);
            }
        });
        if (selectedRowIds.size === 0) return;
        const allSeatsToSelect = [];
        selectedRowIds.forEach(rowId => {
            const rowSeats = canvas.getObjects().filter(o => o.type === "group" && o.rowId === rowId);
            allSeatsToSelect.push(...rowSeats);
        });
        const currentSelection = canvas.getActiveObject();
        const currentlySelected = currentSelection && currentSelection.type === 'activeSelection'
            ? currentSelection.getObjects()
            : (currentSelection ? [currentSelection] : []);
        if (!this.arraysEqual(currentlySelected, allSeatsToSelect)) {
            canvas.discardActiveObject();
           
            const sel = new fabric.ActiveSelection(allSeatsToSelect, { canvas });
           
            sel.set({
                borderColor: "rgb(7, 132, 250)",
                cornerColor: "rgb(7, 132, 250)",
                backgroundColor: "rgba(7, 132, 250, 0.3)"
            });
            canvas.setActiveObject(sel);
            canvas.renderAll();
        }
    },

    arraysEqual(arr1, arr2) {
        if (arr1.length !== arr2.length) return false;
        const arr2Set = new Set(arr2);
        for (let obj of arr1) {
            if (!arr2Set.has(obj)) return false;
        }
        return true;
    },

    enableSeatCreateMode(canvasId) {
        const canvas = this.canvases[canvasId];
        this.mode = "create";
        this.setMode("create");
        this.isDrawingSeats = false;
        canvas.selection = false;
        canvas.discardActiveObject();
        canvas.forEachObject(o => o.selectable = false);
    },

    enableRectangleMode(canvasId) {
        this.disableRowCreateMode(canvasId);
        const canvas = this.canvases[canvasId];
        this.clearRowGuide(canvas);
        this.mode = "rectangle";
        this.setMode("rectangle");
        this.isDrawingRect = false;
        canvas.selection = false;
        canvas.forEachObject(o => o.selectable = false);
        this.disableValidation();
    },

    enableGeneralCategoryMode(canvasId) {
        this.disableRowCreateMode(canvasId);
        const canvas = this.canvases[canvasId];
        this.clearRowGuide(canvas);
        this.mode = "general";
        this.setMode("general");
        this.isDrawingRect = false;
        canvas.selection = false;
        canvas.forEachObject(o => o.selectable = false);
        this.disableValidation();
    },

    enableRowCreateMode(canvasId, direction = "horizontal") {
        const canvas = this.canvases[canvasId];
        this.mode = "row";
        this.setMode("row");
        this.rowDirection = direction;
        canvas.selection = false;
        canvas.forEachObject(o => o.selectable = false);
        this.disableValidation();
    },

    enableSegmentRowMode(canvasId, direction = "horizontal") {
        const canvas = this.canvases[canvasId];
        this.mode = "segmentRow";
        this.setMode("segmentRow");
        this.rowDirection = direction;
        canvas.selection = false;
        canvas.forEachObject(o => o.selectable = false);
        this.disableValidation();
    },

    enableMultipleRowMode(canvasId, direction = "horizontal") {
        const canvas = this.canvases[canvasId];
        this.mode = "multiRow";
        this.setMode("multiRow");
        this.firstRowSeatCount = 0;
        this.firstRowDirection = direction;
        this.rowDirection = direction;
        this.isDrawingMultipleRows = false;
        this.isDrawingFirstRow = false;
        this.multiRowActive = false;
        this.multiRowStartPoint = null;
        this.multiRowCurrentPoint = null;
        this.multiRowDirection = null;
        this.multiRowAngle = 0;
        this.firstRowStartX = null;
        this.firstRowStartY = null;
        this.firstRowBaseX = null;
        this.firstRowBaseY = null;
        this.lastRowX = null;
        this.lastRowY = null;
        this.rowAngle = 0;
        this.firstRowAngle = 0;
        this.clearAllPreviews(canvas);
        this.clearGeneratedRows(canvas);
        canvas.selection = false;
        canvas.forEachObject(o => o.selectable = false);
        this.disableValidation();
    },

    disableRowCreateMode(canvasId) {
        this.mode = null;
        const canvas = this.canvases[canvasId];
        if (this.hoverStartGuide) {
            canvas.remove(this.hoverStartGuide);
            this.hoverStartGuide = null;
        }
    },

    setMode(mode) {
        this.mode = mode;
        const canvas = this.canvases["seatCanvas"];
        if (mode !== "select") {
            canvas.selection = false;
            canvas.getObjects().forEach(obj => {
                obj.selectable = false;
                obj.evented = false;
            });
        } else {
            canvas.selection = true;
            canvas.getObjects().forEach(obj => {
                obj.selectable = true;
                obj.evented = true;
            });
        }
        canvas.renderAll();
    },

    addSeat(canvasId, x, y) {
        const canvas = this.canvases[canvasId];
        const radius = 8;
        const seatId = "Seat-" + (this.seatCounter++);
        const circle = new fabric.Circle({
            radius: radius,
            fill: "white",
            originX: "center",
            originY: "center",
            stroke: "black",
            strokeWidth: 1
        });
        const text = new fabric.Text("", {
            fontSize: 10,
            fontWeight: "bold",
            fill: "black",
            originX: "center",
            originY: "center",
            evented: false,
            selectable: false
        });
        const seatGroup = new fabric.Group([circle, text], {
            left: x,
            top: y,
            originX: "center",
            originY: "center",
            hasControls: false,
            subTargetCheck: true,
            seatLabel: "",
            seatId: seatId,
            categoryId: "",
            seatType: ""
        });
        seatGroup.circle = circle;
        seatGroup.textObj = text;
        seatGroup.seatId = seatId;
        seatGroup.seatStatus = "available";
        canvas.add(seatGroup);
        canvas.renderAll();
        this.lastSeat = { x, y };
    },

    applySeatLabels(canvasId) {
        const canvas = this.canvases[canvasId];
        const active = canvas.getActiveObject();
        if (!active) return;
        let seats = [];
        if (active.type === "activeSelection") {
            seats = active._objects.slice();
        } else {
            seats = [active];
        }
        seats.sort((a, b) => {
            const rowTolerance = 15;
            const aRow = Math.round(a.top / rowTolerance) * rowTolerance;
            const bRow = Math.round(b.top / rowTolerance) * rowTolerance;
            if (aRow === bRow) {
                return a.left - b.left;
            }
            return aRow - bRow;
        });
        const ddl = document.getElementById("ddlseat").value;
        if (!ddl) return;
        const direction = document.getElementById("ddldirection")?.value || "LTR";
        const rows = this.groupSeatsByRow(seats);
        Object.keys(rows).forEach(rowKey => {
            const rowSeats = rows[rowKey];
            rowSeats.sort((a, b) => a.left - b.left);
            const totalSeats = rowSeats.length;
            rowSeats.forEach((seat, indexInRow) => {
                if (!seat.textObj) return;
                let seatIndex;
                if (direction === "RTL") {
                    seatIndex = totalSeats - 1 - indexInRow;
                } else {
                    seatIndex = indexInRow;
                }
                var custominput = document.getElementById("txtcustomlbl");
                let customlbl = "";
                if (custominput) {
                    customlbl = custominput.value;
                }
                const label = this.getSeatLabel(seatIndex, ddl, customlbl);
                seat.textObj.set({ text: label, fill: "black" });
                seat.set('seatLabel', label);
                const rowLabel = seat.rowLabel || seat.get('rowLabel') || '';
                let seatId;
                if (rowLabel && rowLabel.trim() !== '') {
                    seatId = rowLabel + label;
                } else {
                    seatId = "Seat-" + label;
                }
                seat.set('seatId', seatId);
                seat.seatId = seatId;
            });
        });
        canvas.renderAll();
        saveState(canvas);
        this.showValidation(canvas);
    },

    getSeatLabel(index, format, customStart = null) {
        switch (format) {
            case "alphabetUpper":
                return this.toAlphabet(index, true);
            case "alphabetLower":
                return this.toAlphabet(index, false);
            case "roman":
                return this.toRoman(index + 1);
            case "number":
                return (index + 1).toString();
            case "custom":
                if (!customStart) return "";
                if (!isNaN(customStart)) {
                    const startNumber = parseInt(customStart);
                    return (startNumber + index).toString();
                }
                if (/^[a-zA-Z]+$/.test(customStart)) {
                    const isUpper = customStart === customStart.toUpperCase();
                    let startIndex = 0;
                    const base = isUpper ? 65 : 97;
                    for (let i = 0; i < customStart.length; i++) {
                        startIndex *= 26;
                        startIndex += (customStart.charCodeAt(i) - base + 1);
                    }
                    return this.toAlphabet(startIndex - 1 + index, isUpper);
                }
                return "";
            default:
                return "";
        }
    },

    toAlphabet(index, isUpper = true) {
        let result = "";
        let base = isUpper ? 65 : 97;
        index += 1;
        while (index > 0) {
            index--;
            result = String.fromCharCode(base + (index % 26)) + result;
            index = Math.floor(index / 26);
        }
        return result;
    },

    toRoman(num) {
        const map = [
            { v: 1000, s: 'M' }, { v: 900, s: 'CM' }, { v: 500, s: 'D' }, { v: 400, s: 'CD' },
            { v: 100, s: 'C' }, { v: 90, s: 'XC' }, { v: 50, s: 'L' }, { v: 40, s: 'XL' },
            { v: 10, s: 'X' }, { v: 9, s: 'IX' }, { v: 5, s: 'V' }, { v: 4, s: 'IV' }, { v: 1, s: 'I' }
        ];
        let result = "";
        map.forEach(({ v, s }) => {
            while (num >= v) { result += s; num -= v; }
        });
        return result;
    },

    applyRowLabel(canvasId) {
        const canvas = this.canvases[canvasId];
        let active = canvas.getActiveObject();
        if (!active) {
            showNotification("Please select seats first.", "info");
            return;
        }
        let seats = [];
        if (active.type === "activeSelection") {
            seats = active._objects.filter(o => o.type === "group");
        } else if (active.type === "group") {
            seats = [active];
        } else {
            showNotification("Please select seats to label.", "info");
            return;
        }
        if (seats.length === 0) return;
        canvas.renderOnAddRemove = false;
        const removedLabels = new Set();
        seats.forEach(seat => {
            if (seat.rowLabelObject) {
                removedLabels.add(seat.rowLabelObject);
            }
            seat.set('rowLabel', '');
            seat.rowLabel = '';
            seat.rowLabelObject = null;
            const seatLabel = seat.seatLabel || seat.get('seatLabel') || "";
            if (seatLabel) {
                seat.set('seatId', seatLabel);
                seat.seatId = seatLabel;
            }
        });
        removedLabels.forEach(labelObj => {
            canvas.remove(labelObj);
        });
        seats.sort((a, b) => {
            const rowY = Math.round(a.top / 10) * 10;
            const rowY2 = Math.round(b.top / 10) * 10;
            if (rowY === rowY2) {
                return a.left - b.left;
            }
            return rowY - rowY2;
        });
        const rows = this.groupSeatsByRow(seats);
        const rowCount = Object.keys(rows).length;
        const direction = document.getElementById("ddldirection")?.value || "LTR";
        if (rowCount == 1) {
            const inputLabel = document.getElementById("txtrowlbl").value;
            if (inputLabel) {
                const rowSeats = rows[0];
                let anchorSeat = direction === "RTL"
                    ? rowSeats.reduce((a, b) => getAbsolutePosition(a).x > getAbsolutePosition(b).x ? a : b)
                    : rowSeats.reduce((a, b) => getAbsolutePosition(a).x < getAbsolutePosition(b).x ? a : b);
                const anchorPos = getAbsolutePosition(anchorSeat);
                const labelSpacing = 25;
                const labelX = direction === "RTL" ? anchorPos.x + labelSpacing : anchorPos.x - labelSpacing;
                const labelY = anchorPos.y;
                this.removeRowLabelsForRow(canvas, rowSeats);
                const rowText = this.addRowLabel(canvasId, labelX, labelY, inputLabel);
                rowSeats.forEach(seat => {
                    seat.set('rowLabel', inputLabel);
                    seat.rowLabel = inputLabel;
                    seat.rowLabelObject = rowText;
                    const seatLabel = seat.seatLabel || seat.get('seatLabel') || "";
                    if (seatLabel) {
                        const seatId = inputLabel + seatLabel;
                        seat.set('seatId', seatId);
                        seat.seatId = seatId;
                    }
                });
            }
            canvas.renderOnAddRemove = true;
            canvas.requestRenderAll();
            return;
        }
        const labelType = document.getElementById("ddlrow").value;
        if (!labelType) {
            showNotification("Please select a row label type.");
            canvas.renderOnAddRemove = true;
            return;
        }
        const sortedRowKeys = Object.keys(rows).sort((a, b) => {
            const posA = getAbsolutePosition(rows[a][0]);
            const posB = getAbsolutePosition(rows[b][0]);
            return posA.y - posB.y;
        });
        sortedRowKeys.forEach((rowKey, rowIndex) => {
            const rowSeats = rows[rowKey];
            if (rowSeats.length === 0) return;
            let rowLabel;
            switch (labelType) {
                case "alphabetUpper":
                    rowLabel = String.fromCharCode(65 + rowIndex);
                    break;
                case "alphabetLower":
                    rowLabel = String.fromCharCode(97 + rowIndex);
                    break;
                case "roman":
                    rowLabel = this.toRoman(rowIndex + 1);
                    break;
                case "number":
                    rowLabel = (rowIndex + 1).toString();
                    break;
                case "custom":
                    const customLabel = document.getElementById("txtCustomRowLabel").value.trim();
                    if (!customLabel) {
                        showNotification("Enter custom row label");
                        return;
                    }
                    if (!isNaN(customLabel)) {
                        rowLabel = (parseInt(customLabel) + rowIndex).toString();
                    } else {
                        const startIndex = this.columnNameToNumber(customLabel.toUpperCase());
                        rowLabel = this.numberToColumnName(startIndex + rowIndex);
                    }
                    break;
                default:
                    rowLabel = "";
            }
            let anchorSeat = direction === "RTL"
                ? rowSeats.reduce((a, b) => getAbsolutePosition(a).x > getAbsolutePosition(b).x ? a : b)
                : rowSeats.reduce((a, b) => getAbsolutePosition(a).x < getAbsolutePosition(b).x ? a : b);
            const anchorPos = getAbsolutePosition(anchorSeat);
            const labelSpacing = 25;
            const labelX = direction === "RTL" ? anchorPos.x + labelSpacing : anchorPos.x - labelSpacing;
            const labelY = anchorPos.y;
            const shouldRemoveLabel = rowSeats.every(seat => seats.includes(seat));
            if (shouldRemoveLabel) {
                this.removeRowLabelsForRow(canvas, rowSeats);
            }
            const rowText = this.addRowLabel(canvasId, labelX, labelY, rowLabel);
            rowSeats.forEach(seat => {
                seat.set('rowLabel', rowLabel);
                seat.rowLabel = rowLabel;
                seat.rowLabelObject = rowText;
                const seatLabel = seat.seatLabel || seat.get('seatLabel') || "";
                if (seatLabel) {
                    const seatId = rowLabel + seatLabel;
                    seat.set('seatId', seatId);
                    seat.seatId = seatId;
                }
            });
        });
        canvas.renderOnAddRemove = true;
        canvas.requestRenderAll();
        saveState(canvas);
        this.showValidation(canvas);
    },

    removeRowLabelsForRow(canvas, rowSeats) {
        if (!rowSeats || rowSeats.length === 0) return;
        const rowY = rowSeats.reduce((sum, seat) => {
            return sum + getAbsolutePosition(seat).y;
        }, 0) / rowSeats.length;
        const thresholdY = 15;
        const xPositions = rowSeats.map(seat => getAbsolutePosition(seat).x);
        const minX = Math.min(...xPositions);
        const maxX = Math.max(...xPositions);
        const thresholdX = 20;
        const labelsToRemove = [];
        canvas.getObjects().forEach(obj => {
            if (obj.isRowLabel === true) {
                const labelY = obj.top;
                const labelX = obj.left;
                const isSameRow = Math.abs(labelY - rowY) < thresholdY;
                const isWithinXRange = labelX >= (minX - thresholdX) && labelX <= (maxX + thresholdX);
                if (isSameRow && isWithinXRange) {
                    labelsToRemove.push(obj);
                }
            }
        });
        labelsToRemove.forEach(lbl => canvas.remove(lbl));
    },

    columnNameToNumber(name) {
        let number = 0;
        for (let i = 0; i < name.length; i++) {
            number = number * 26 + (name.charCodeAt(i) - 64);
        }
        return number;
    },

    numberToColumnName(num) {
        let columnName = "";
        while (num > 0) {
            let remainder = (num - 1) % 26;
            columnName = String.fromCharCode(65 + remainder) + columnName;
            num = Math.floor((num - 1) / 26);
        }
        return columnName;
    },

    groupSeatsByRow(seats) {
        const rows = {};
        seats.forEach(seat => {
            const rowId = seat.rowId || seat.get("rowId") || 0;
            if (!rows[rowId]) {
                rows[rowId] = [];
            }
            rows[rowId].push(seat);
        });
        const sortedRows = {};
        Object.values(rows)
            .sort((a, b) => {
                const avgA = a.reduce((s, x) => s + x.top, 0) / a.length;
                const avgB = b.reduce((s, x) => s + x.top, 0) / b.length;
                return avgA - avgB;
            })
            .forEach((row, index) => {
                /* row.sort((a, b) => a.left - b.left);*/
                row.sort((a, b) =>
                    a.getCenterPoint().x -
                    b.getCenterPoint().x
                );
                sortedRows[index] = row;
            });
        return sortedRows;
    },

    addRowLabel(canvasId, x, y, label) {
        const canvas = this.canvases[canvasId];
        const existingLabels = canvas.getObjects().filter(obj =>
            obj.type === 'text' && Math.abs(obj.left - x) < 20 && Math.abs(obj.top - y) < 20
        );
        existingLabels.forEach(labelObj => canvas.remove(labelObj));
        const rowText = new fabric.Text(label, {
            left: x,
            top: y,
            fontSize: 14,
            fontWeight: "normal",
            fill: "black",
            originX: "center",
            originY: "center",
            hasControls: false,
            selectable: false,
            evented: false
        });
        rowText.isRowLabel = true;
        rowText.rowLabel = label;
        rowText.text = label;
        rowText.set('isRowLabel', true);
        rowText.set('rowLabel', label);
        rowText.set('text', label);
        canvas.add(rowText);
        canvas.moveTo(rowText, canvas.getObjects().length - 1);
        canvas.renderAll();
        return rowText;
    },

    setSeatColor(canvasId) {
        const canvas = this.canvases[canvasId];
        const active = canvas.getActiveObject();
        if (!active) return;
        const selectedColor = document.getElementById("ddlcolor").value;
        const selectedCat = document.getElementById("ddlcolor").selectedOptions[0].text;
        let seats = [];
        if (active.type === "activeSelection") {
            seats = active._objects.slice();
        } else {
            seats = [active];
        }
        seats.forEach(seat => {
            if (seat.objectType === "seat" || seat.type === "group") {
                if (!seat.circle) return;
                seat.circle.set({ fill: selectedColor, stroke: null, strokeWidth: 0 });
                seat.set('fill', selectedColor);
                seat.set('categoryId', selectedColor);
                seat.set('categoryName', selectedCat);
            } else if (seat.objectType === "genrectangle" || seat.type === "rect") {
                const isGenRectangle = seat.objectType === "genrectangle";
                const isGeneralRect = seat.createdBy === 'rectangleTool' && seat.fill && seat.fill.includes('0.1');
                if (isGenRectangle || isGeneralRect) {
                    seat.set({ fill: selectedColor, stroke: selectedColor, strokeWidth: 1 });
                    seat.set('categoryId', selectedColor);
                    seat.set('categoryName', selectedCat);
                    if (seat.labelTextId) {
                        const labelText = canvas.getObjects().find(o => o.id === seat.labelTextId);
                        if (labelText) {
                            labelText.set('fill', getContrastColor(selectedColor));
                        }
                    }
                }
            }
        });
        canvas.renderAll();
        saveState(canvas);
        this.showValidation(canvas);
    },

    toggleSeatStatus(canvasId, seat) {
        const canvas = this.canvases[canvasId];
        const fabricObjects = canvas.getObjects();
        const seatGroup = fabricObjects.find(obj => obj.type === 'group' && obj.seatId === seat.id);
        if (!seatGroup) return;
        const current = seatGroup.seatStatus || 'available';
        let newColor, newStatus;
        if (current === 'available') {
            newColor = "#e7e7e7";
            newStatus = 'sold';
        } else if (current === 'selected') {
            newColor = '#999999';
            newStatus = 'sold';
        } else {
            newColor = '#f2fd58';
            newStatus = 'available';
        }
        if (seatGroup._objects && seatGroup._objects.length > 0) {
            if (seatGroup.circle) {
                seatGroup.circle.set('fill', newColor);
            } else {
                const circleInGroup = seatGroup._objects.find(obj => obj.type === 'circle' || (obj.radius && obj.radius > 0));
                if (circleInGroup) {
                    circleInGroup.set('fill', newColor);
                    circleInGroup.set('dirty', true);
                } else {
                    seatGroup._objects.forEach(obj => {
                        if (obj.fill !== undefined) {
                            obj.set('fill', newColor);
                        }
                    });
                }
            }
        }
        seat.seatStatus = newStatus;
        seatGroup.seatStatus = newStatus;
        if (seat.circle) {
            seat.circle.fill = newColor;
        }
        seatGroup.set('dirty', true);
        canvas.requestRenderAll();
        this.saveLayout(canvasId);
    },

    deleteSelected(canvasId) {
        const canvas = this.canvases[canvasId];
        const active = canvas.getActiveObjects();
        if (!active || active.length === 0) return;
        active.forEach(obj => canvas.remove(obj));
        this.disableValidation();
        canvas.renderAll();
    },

    saveLayout(canvasId) {
        safeExecute(() => {
            const canvas = this.canvases[canvasId];
            if (!canvas) return;
            const invalid = this.validateLabels(canvas);
            const isCategorized = this.isCategorized(canvas);
            if (invalid.length > 0) {
                showNotification("Please label all objects before saving.", "info");
                this.highlightInvalidObjects(invalid, canvas);
                return;
            }
            if (isCategorized.length > 0) {
                showNotification("Please categorize all objects before saving.", "info");
                this.highlightInvalidObjects(isCategorized, canvas);
                return;
            }
            const json = canvas.toJSON([
                'seatLabel', 'seatId', 'categoryId', 'categoryName', 'seatType', 'holdToken',
                'rowLabel', 'rowId', 'isRowLabel', 'seatStatus',
                'objectType', 'createdBy', 'rectangleId', 'rectangleLabel', 'rectangleIcon',
                'categoryId', 'categoryName', 'capacity', 'generalLabel'
            ]);
            const jsonStr = JSON.stringify(json);
            if (json.objects.length > 0) {
                DotNet.invokeMethodAsync("TTWSeating", "SaveSeatingLayout", jsonStr);
                showNotification("Saved Successfully", "success");
            }
        }, 'Failed to save layout');
    },

    //loadLayout(canvasId, jsonString) {
    //    const canvas = this.canvases[canvasId];
    //    let json;
    //    try {
    //        json = JSON.parse(jsonString);
    //    } catch (error) {
    //        console.error("JSON parse error:", error);
    //        return;
    //    }
    //    canvas.clear();
    //    if (!json.objects || !Array.isArray(json.objects)) {
    //        console.error("No objects array in JSON");
    //        return;
    //    }
    //    json.objects.forEach((objData, index) => {
    //        if (objData.objectType === 'genrectangle') {
    //            this.recreateGeneralRectangleFromData(canvas, objData);
    //        } else if (objData.objectType === 'rectangle') {
    //            this.recreateRectangleFromData(canvas, objData);
    //        } else if (objData.type === "group" && objData.seatId) {
    //            this.recreateSeatFromData(canvas, objData);
    //        }
    //    });
    //    json.objects.forEach((objData, index) => {
    //        if (objData.type === "text" || objData.type === "i-text") {
    //            if (objData.isRowLabel === true) {
    //                const textValue = objData.text || objData.rowLabel || "";
    //                const rowText = new fabric.Text(textValue, {
    //                    left: objData.left || 0,
    //                    top: objData.top || 0,
    //                    fontSize: objData.fontSize || 14,
    //                    fontWeight: objData.fontWeight || "normal",
    //                    fill: objData.fill || "black",
    //                    originX: objData.originX || "center",
    //                    originY: objData.originY || "center",
    //                    hasControls: false,
    //                    selectable: false,
    //                    evented: false,
    //                    isRowLabel: true,
    //                    rowLabel: objData.rowLabel || textValue
    //                });
    //                rowText.set('isRowLabel', true);
    //                rowText.set('rowLabel', rowText.rowLabel);
    //                canvas.add(rowText);
    //            } else if (objData.isRectangleLabel === true || objData.generalLabel) {
    //                this.recreateRectangleLabel(canvas, objData);
    //            }
    //        }
    //    });
    //    canvas.renderAll();
    //    this.fitAndCenterChart(canvas);
    //},

    loadLayout(canvasId, jsonString) {
        const canvas = this.canvases[canvasId];

        let json;
        try {
            json = JSON.parse(jsonString);
        } catch (error) {
            console.error("JSON parse error:", error);
            return;
        }

        canvas.clear();

        if (!json.objects || !Array.isArray(json.objects)) {
            console.error("No objects array in JSON");
            return;
        }

        // Load shapes and seats
        json.objects.forEach((objData) => {
            if (objData.objectType === 'genrectangle') {
                this.recreateGeneralRectangleFromData(canvas, objData);
            }
            else if (objData.objectType === 'rectangle') {
                this.recreateRectangleFromData(canvas, objData);
            }
            else if (objData.type === "group" && objData.seatId) {
                this.recreateSeatFromData(canvas, objData);
            }
        });

        // Load labels
        json.objects.forEach((objData) => {

            if (objData.type === "text" || objData.type === "i-text") {

                if (objData.isRowLabel === true) {

                    const textValue = objData.text || objData.rowLabel || "";

                    const rowText = new fabric.Text(textValue, {
                        left: objData.left || 0,
                        top: objData.top || 0,
                        fontSize: objData.fontSize || 14,
                        fontWeight: objData.fontWeight || "normal",
                        fill: objData.fill || "black",
                        originX: objData.originX || "center",
                        originY: objData.originY || "center",
                        hasControls: false,
                        selectable: false,
                        evented: false,
                        isRowLabel: true,
                        rowLabel: objData.rowLabel || textValue
                    });

                    rowText.set('isRowLabel', true);
                    rowText.set('rowLabel', rowText.rowLabel);

                    canvas.add(rowText);
                }
                else if (objData.isRectangleLabel === true || objData.generalLabel) {
                    this.recreateRectangleLabel(canvas, objData);
                }
            }
        });

        // Render first
        canvas.renderAll();

        // Fit and center
        this.fitAndCenterChart(canvas);

        // VERY IMPORTANT - refresh hit detection
        canvas.calcOffset();

        canvas.forEachObject((obj) => {
            obj.setCoords();

            // Update coords for group children too
            if (obj.type === "group" && obj._objects) {
                obj._objects.forEach((child) => {
                    child.setCoords();
                });
            }
        });

        canvas.requestRenderAll();
    },
    //recreateSeatFromData(canvas, objData) {
    //    const radius = 8;
    //    const circle = new fabric.Circle({
    //        radius: radius,
    //        fill: objData.categoryId || "white",
    //        originX: "center",
    //        originY: "center",
    //        stroke: objData.categoryId || "black",
    //        strokeWidth: objData.strokeWidth || 1
    //    });
    //    const seatLabel = objData.seatLabel || "";
    //    const text = new fabric.Text(seatLabel, {
    //        fontSize: 10,
    //        fontWeight: "bold",
    //        fill: "white",
    //        originX: "center",
    //        originY: "center",
    //        evented: false,
    //        selectable: false
    //    });
    //    const seatGroup = new fabric.Group([circle, text], {
    //        left: objData.left || 0,
    //        top: objData.top || 0,
    //        originX: "center",
    //        originY: "center",
    //        hasControls: false,
    //        subTargetCheck: true
    //    });
    //    seatGroup.seatLabel = objData.seatLabel || "";
    //    seatGroup.seatId = objData.seatId || `Seat-${seatLabel}`;
    //    seatGroup.categoryId = objData.categoryId || "";
    //    seatGroup.categoryName = objData.categoryName || "";
    //    seatGroup.seatType = objData.seatType || "";
    //    seatGroup.rowLabel = objData.rowLabel || "";
    //    seatGroup.seatStatus = objData.seatStatus || "available";
    //    seatGroup.isRowLabel = objData.isRowLabel || false;
    //    seatGroup.set('seatLabel', seatGroup.seatLabel);
    //    seatGroup.set('seatId', seatGroup.seatId);
    //    seatGroup.set('categoryId', seatGroup.categoryId);
    //    seatGroup.set('categoryName', seatGroup.categoryName);
    //    seatGroup.set('seatType', seatGroup.seatType);
    //    seatGroup.set('rowLabel', seatGroup.rowLabel);
    //    seatGroup.set('seatStatus', seatGroup.seatStatus);
    //    seatGroup.set('isRowLabel', seatGroup.isRowLabel);
    //    seatGroup.rowId = objData.rowId || objData.rowLabel || "";
    //    seatGroup.set('rowId', seatGroup.rowId);
    //    seatGroup.circle = circle;
    //    seatGroup.textObj = text;
    //    canvas.add(seatGroup);
    //},
    recreateSeatFromData(canvas, objData) {

        const radius = 8;

        const circle = new fabric.Circle({
            radius: radius,
            fill: objData.categoryId || "white",
            stroke: objData.categoryId || "black",
            strokeWidth: objData.strokeWidth || 1,
            originX: "center",
            originY: "center",
            selectable: false,
            evented: false
        });

        const text = new fabric.Text(objData.seatLabel || "", {
            fontSize: 10,
            fontWeight: "bold",
            fill: "white",
            originX: "center",
            originY: "center",
            selectable: false,
            evented: false
        });

        const seatGroup = new fabric.Group([circle, text], {
            left: objData.left || 0,
            top: objData.top || 0,
            originX: "center",
            originY: "center",
            hasControls: false,
            hasBorders: false,
            selectable: true,
            evented: true,
            subTargetCheck: true,
            objectCaching: false
        });

        seatGroup.seatLabel = objData.seatLabel || "";
        seatGroup.seatId = objData.seatId || `Seat-${seatGroup.seatLabel}`;
        seatGroup.categoryId = objData.categoryId || "";
        seatGroup.categoryName = objData.categoryName || "";
        seatGroup.seatType = objData.seatType || "";
        seatGroup.rowLabel = objData.rowLabel || "";
        seatGroup.seatStatus = objData.seatStatus || "available";
        seatGroup.rowId = objData.rowId || objData.rowLabel || "";

        seatGroup.textObj = text;
        seatGroup.circle = circle;

        seatGroup.setCoords();

        canvas.add(seatGroup);
    },
    getSelectedSeatsForBooking(canvasId) {
        const canvas = this.canvases[canvasId];
        if (!canvas || !canvas.selectedSeats) return [];
        return canvas.selectedSeats;
    },

    clearSelectedSeats(canvasId) {
        const canvas = this.canvases[canvasId];
        if (canvas && canvas.selectedSeats) {
            canvas.selectedSeats = [];
        }
        canvas.forEachObject(obj => {
            if (obj.type === 'group' && obj.textObj) {
                if (obj.textObj.text === "✔") {
                    obj.textObj.set({ text: "", fontWeight: "normal", fontSize: 10 });
                    obj.set("isSelected", false);
                    obj.isSelected = false;
                }
            }
        });
        canvas.renderAll();
    },

    recreateRectangleFromData(canvas, objData) {
        const rect = new fabric.Rect({
            left: objData.left || 0,
            top: objData.top || 0,
            width: objData.width || 50,
            height: objData.height || 50,
            fill: objData.fill || "rgba(0,0,0,0.1)",
            stroke: objData.stroke || "black",
            strokeWidth: objData.strokeWidth || 1,
            strokeDashArray: objData.strokeDashArray || null,
            selectable: true,
            evented: true,
            hasControls: true,
            hasBorders: true,
            lockUniScaling: false,
            objectType: objData.objectType || 'rectangle',
            createdBy: objData.createdBy || 'rectangleTool',
            rectangleId: objData.rectangleId || `rect-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            rectangleLabel: objData.rectangleLabel || ""
        });
        rect.set('objectType', rect.objectType);
        rect.set('createdBy', rect.createdBy);
        rect.set('rectangleId', rect.rectangleId);
        rect.set('rectangleLabel', objData.rectangleLabel || "");
        rect.set('rectangleIcon', objData.rectangleIcon || "");
        canvas.add(rect);
        if (objData.rectangleLabel) {
            const temp = document.createElement("span");
            temp.innerHTML = objData.rectangleIcon || "";
            const icon = temp.innerText;
            var lbl = icon + " " + objData.rectangleLabel;
            const labelText = new fabric.Text(lbl, {
                fontSize: 14,
                fontWeight: "900",
                fontFamily: "Font Awesome 6 Free",
                fill: "black",
                originX: "center",
                originY: "center",
                left: rect.left + rect.width / 2,
                top: rect.top + rect.height / 2,
                selectable: false,
                evented: false
            });
            canvas.add(labelText);
            canvas.bringToFront(labelText);
            rect.labelText = labelText;
        }
    },

    recreateGeneralRectangleFromData(canvas, objData) {
        const rect = new fabric.Rect({
            left: objData.left || 0,
            top: objData.top || 0,
            width: objData.width || 50,
            height: objData.height || 50,
            fill: objData.fill || objData.categoryId || "rgba(0,0,0,0.1)",
            stroke: objData.stroke || objData.categoryId || "black",
            strokeWidth: objData.strokeWidth || 1,
            selectable: true,
            evented: true,
            hasControls: true,
            hasBorders: true,
            lockUniScaling: false,
            objectType: objData.objectType || 'genrectangle',
            createdBy: objData.createdBy || 'rectangleTool',
            rectangleId: objData.rectangleId || `rect-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            rectangleLabel: objData.rectangleLabel || '',
            capacity: objData.capacity || 0,
            categoryId: objData.categoryId || '',
            categoryName: objData.categoryName || '',
            generalLabel: objData.generalLabel || null
        });
        rect.set('objectType', rect.objectType);
        rect.set('createdBy', rect.createdBy);
        rect.set('rectangleId', rect.rectangleId);
        rect.set('rectangleLabel', rect.rectangleLabel);
        rect.set('capacity', rect.capacity);
        rect.set('categoryId', rect.categoryId);
        rect.set('categoryName', rect.categoryName);
        rect.set('generalLabel', rect.generalLabel);
        canvas.add(rect);
    },

    recreateRectangleLabel(canvas, objData) {
        const labelText = new fabric.Text(objData.text || '', {
            left: objData.left || 0,
            top: objData.top || 0,
            fontSize: objData.fontSize || 12,
            fontWeight: objData.fontWeight || "bold",
            fill: objData.fill || "black",
            originX: objData.originX || "center",
            originY: objData.originY || "center",
            selectable: false,
            evented: false,
            text: objData.generalLabel || '',
            rectangleId: objData.rectangleId,
            isRectangleLabel: true,
            textAlign: 'center',
            id: objData.id || `label-${objData.rectangleId}`
        });
        const rect = canvas.getObjects().find(obj => obj.rectangleId === objData.rectangleId);
        if (rect) {
            rect.labelText = labelText;
            rect.labelTextId = labelText.id;
            rect.generalLabel = labelText.text;
            rect.set('labelTextId', labelText.id);
            rect.set('generalLabel', labelText.text);
            if (rect.categoryId || rect.fill) {
                const rectColor = rect.categoryId || rect.fill;
                if (rectColor && typeof rectColor === 'string' && rectColor.startsWith('#')) {
                    labelText.set('fill', getContrastColor(rectColor));
                }
            }
        }
        canvas.add(labelText);
    },

    createSeatRow(canvasId, start, end) {
        const canvas = this.canvases[canvasId];
        const spacing = this.seatSpacing || 20;
        let count;
        if (this.rowDirection === "horizontal") {
            count = Math.floor(Math.abs(end.x - start.x) / spacing) + 1;
        } else {
            count = Math.floor(Math.abs(end.y - start.y) / spacing) + 1;
        }
        if (count <= 0) return;
        const rowLabel = "";
        const rowId = `row-${rowLabel}-${Date.now()}`;
        for (let i = 0; i < count; i++) {
            const x = this.rowDirection === "horizontal" ? start.x + i * spacing : start.x;
            const y = this.rowDirection === "vertical" ? start.y + i * spacing : start.y;
            const seatLabel = (i + 1).toString();
            const seatId = `${rowLabel}${seatLabel}`;
            this.createSeat(canvas, x, y, seatLabel, seatId, rowLabel, rowId);
        }
        if (this.rowDirection === "horizontal") {
            this.rowStart = { x: start.x, y: start.y + spacing * 2 };
        } else {
            this.rowStart = { x: start.x + spacing * 2, y: start.y };
        }
        this.rowIndex++;
        canvas.renderAll();
    },

    createSeat(canvas, x, y, seatLabel, seatId, rowLabel, rowId) {
        const circle = new fabric.Circle({
            radius: 8,
            fill: "white",
            originX: "center",
            originY: "center",
            stroke: "black",
            strokeDashArray: null,
        });
        const text = new fabric.Text("", {
            fontSize: 10,
            fontWeight: "bold",
            fill: "black",
            originX: "center",
            originY: "center",
            evented: false,
            selectable: false
        });
        const seatGroup = new fabric.Group([circle, text], {
            left: x,
            top: y,
            originX: "center",
            originY: "center",
            hasControls: false,
        });
        seatGroup.circle = circle;
        seatGroup.textObj = text;
        seatGroup.seatLabel = seatLabel;
        seatGroup.seatId = seatId;
        seatGroup.rowLabel = rowLabel;
        seatGroup.rowId = rowId;
        seatGroup.seatStatus = "available";
        seatGroup.objectType = "seat";
        seatGroup.categoryId = "";
        seatGroup.set({ seatLabel, seatId, rowLabel, rowId, seatStatus: "available", categoryId: "" });
        canvas.add(seatGroup);
        return seatGroup;
    },

    clearPreviewLines(canvas) {
        if (!this.previewLines) return;
        Object.values(this.previewLines).forEach(line => {
            if (line) canvas.remove(line);
        });
        this.previewLines = { start: null, end: null, top: null, bottom: null };
    },

    updateRowBoundaryLines(canvas, start, pointer, direction, seatCount) {
        const spacing = this.seatSpacing || 20;
        const seatRadius = 8;
        const length = (seatCount - 1) * spacing;
        let x1, y1, x2, y2;
        if (direction === "horizontal") {
            const left = start.x;
            const right = start.x + length;
            const top = start.y - seatRadius * 2;
            const bottom = start.y + seatRadius * 2;
            this.previewLines.start = this.createOrUpdateLine(canvas, this.previewLines.start, left, top, left, bottom);
            this.previewLines.end = this.createOrUpdateLine(canvas, this.previewLines.end, right, top, right, bottom);
            this.previewLines.top = this.createOrUpdateLine(canvas, this.previewLines.top, left, top, right, top);
            this.previewLines.bottom = this.createOrUpdateLine(canvas, this.previewLines.bottom, left, bottom, right, bottom);
        } else {
            const top = start.y;
            const bottom = start.y + length;
            const left = start.x - seatRadius * 2;
            const right = start.x + seatRadius * 2;
            this.previewLines.start = this.createOrUpdateLine(canvas, this.previewLines.start, left, top, right, top);
            this.previewLines.end = this.createOrUpdateLine(canvas, this.previewLines.end, left, bottom, right, bottom);
            this.previewLines.top = this.createOrUpdateLine(canvas, this.previewLines.top, left, top, left, bottom);
            this.previewLines.bottom = this.createOrUpdateLine(canvas, this.previewLines.bottom, right, top, right, bottom);
        }
    },

    createOrUpdateLine(canvas, line, x1, y1, x2, y2) {
        if (!line) {
            line = new fabric.Line([x1, y1, x2, y2], {
                stroke: "#2196F3",
                strokeDashArray: [5, 5],
                selectable: false,
                evented: false
            });
            canvas.add(line);
        } else {
            line.set({ x1, y1, x2, y2 });
        }
        return line;
    },

    createOrUpdateGuide(canvas, line, x1, y1, x2, y2) {
        if (!line) {
            line = new fabric.Line([x1, y1, x2, y2], {
                stroke: "#FF5722",
                strokeDashArray: [4, 4],
                selectable: false,
                evented: false
            });
            canvas.add(line);
        } else {
            line.set({ x1, y1, x2, y2 });
        }
        return line;
    },

    updateFullHeightRowGuides(canvas, start, direction, seatCount) {
        const spacing = this.seatSpacing || 20;
        const length = (seatCount - 1) * spacing;
        if (direction === "horizontal") {
            const startX = start.x;
            const endX = start.x + length;
            this.alignmentGuides.start = this.createOrUpdateGuide(canvas, this.alignmentGuides.start, startX, 0, startX, canvas.height);
            this.alignmentGuides.end = this.createOrUpdateGuide(canvas, this.alignmentGuides.end, endX, 0, endX, canvas.height);
        } else {
            const startY = start.y;
            const endY = start.y + length;
            this.alignmentGuides.start = this.createOrUpdateGuide(canvas, this.alignmentGuides.start, 0, startY, canvas.width, startY);
            this.alignmentGuides.end = this.createOrUpdateGuide(canvas, this.alignmentGuides.end, 0, endY, canvas.width, endY);
        }
    },

    clearAlignmentGuides(canvas) {
        if (!this.alignmentGuides) return;
        Object.values(this.alignmentGuides).forEach(line => {
            if (line) canvas.remove(line);
        });
        this.alignmentGuides = { start: null, end: null };
    },

    updateHoverStartGuide(canvas, pointer, direction) {
        if (this.hoverStartGuide) {
            canvas.remove(this.hoverStartGuide);
            this.hoverStartGuide = null;
        }
        if (direction === "horizontal") {
            this.hoverStartGuide = new fabric.Line([pointer.x, 0, pointer.x, canvas.height], {
                stroke: "#9C27B0",
                selectable: false,
                evented: false
            });
        } else {
            this.hoverStartGuide = new fabric.Line([0, pointer.y, canvas.width, pointer.y], {
                stroke: "#9C27B0",
                strokeDashArray: [4, 4],
                selectable: false,
                evented: false
            });
        }
        canvas.add(this.hoverStartGuide);
    },

    updateRowHoverGuide(canvas, direction) {
        if (!this.lastRowPosition) return;
        if (this.rowHoverGuide) {
            canvas.remove(this.rowHoverGuide);
            this.rowHoverGuide = null;
        }
        const rowGap = this.rowSpacing || 30;
        if (direction === "horizontal") {
            const nextRowY = this.lastRowPosition.y + rowGap;
            this.rowHoverGuide = new fabric.Line([0, nextRowY, canvas.getWidth(), nextRowY], {
                stroke: "#FF9800",
                strokeWidth: 1.5,
                selectable: false,
                evented: false
            });
        } else {
            const nextRowX = this.lastRowPosition.x + rowGap;
            this.rowHoverGuide = new fabric.Line([nextRowX, 0, nextRowX, canvas.getHeight()], {
                stroke: "#FF9800",
                strokeWidth: 1.5,
                selectable: false,
                evented: false
            });
        }
        canvas.add(this.rowHoverGuide);
        canvas.sendToBack(this.rowHoverGuide);
    },

    clearRowGuide(canvas) {
        if (this.rowHoverGuide) {
            canvas.remove(this.rowHoverGuide);
            this.rowHoverGuide = null;
        }
        if (this.hoverStartGuide) {
            canvas.remove(this.hoverStartGuide);
            this.hoverStartGuide = null;
        }
    },

    applyRectangleLabel(canvasId) {
        const canvas = this.canvases[canvasId];
        const active = canvas.getActiveObject();
        if (!active) {
            showNotification("Please select a rectangle to label");
            return;
        }
        let rect = null;
        if (active.type === "activeSelection") {
            const rectangles = active._objects.filter(obj => obj.objectType === "rectangle");
            if (rectangles.length > 1) {
                showNotification("Please select only ONE rectangle at a time for labeling");
                return;
            }
            if (rectangles.length === 0) {
                showNotification("No rectangle found in selection");
                return;
            }
            rect = rectangles[0];
        } else if (active.type === "rect" && active.objectType === "rectangle") {
            rect = active;
        } else {
            showNotification("Please select a rectangle (not other objects)");
            return;
        }
        const ddlElement = document.getElementById("ddlrect");
        const selectedValue = ddlElement.value;
        if (!selectedValue) {
            showNotification("Please select a label type");
            return;
        }
        const selectedOption = ddlElement.options[ddlElement.selectedIndex];
        const temp = document.createElement("span");
        temp.innerHTML = selectedOption.getAttribute("data-icon");
        const icon = temp.innerText;
        let label = icon + " " + selectedValue;
        if (rect.labelText) {
            canvas.remove(rect.labelText);
            rect.labelText = null;
        }
        const fontSize = Math.min(rect.height * 0.3, rect.width * 0.2, 16);
        const labelText = new fabric.Text(label, {
            fontSize: Math.max(fontSize, 12),
            fontWeight: "900",
            fontFamily: "Font Awesome 6 Free",
            fill: "black",
            originX: "center",
            originY: "center",
            left: rect.left + rect.width / 2,
            top: rect.top + rect.height / 2,
            selectable: false,
            evented: false,
            textAlign: 'center'
        });
        rect.labelText = labelText;
        rect.rectangleLabel = selectedValue;
        rect.rectangleIcon = selectedOption.getAttribute("data-icon");
        rect.set('labelText', labelText);
        rect.set('rectangleLabel', selectedValue);
        rect.set('rectangleIcon', selectedOption.getAttribute("data-icon"));
        canvas.add(labelText);
        canvas.bringToFront(labelText);
        canvas.renderAll();
        return true;
    },

    handleSelectionChanged(canvasId, e) {
        const canvas = this.canvases[canvasId];
        if (!canvas) return;
        const activeObject = canvas.getActiveObject();
        const isRectangleSelected = this.isRectangleSelected(activeObject);
        const isGeneralSelected = this.isGeneralSelected(activeObject);
        const isSeatSelected = this.isSeatSelected(activeObject);
        if (isRectangleSelected) {
            this.toggleRectangleDropdown(isRectangleSelected);
        }
        if (isSeatSelected) {
            this.toggleSeatDropdown(isSeatSelected);
        }
        if (isGeneralSelected) {
            this.toggleGeneralProps(isGeneralSelected);
        }
    },

    handleSelectionCleared(canvasId) {
        const canvas = this.canvases[canvasId];
        this.toggleRectangleDropdown(false);
        this.toggleSeatDropdown(false);
        this.toggleGeneralProps(false);
    },

    isSeatSelected(activeObject) {
        if (!activeObject) return false;
        if (activeObject.type === "activeSelection") {
            const hasSeat = activeObject._objects.some(obj => obj.objectType === "seat" || obj.type === "group");
            if (hasSeat) {
                let seats = activeObject._objects.filter(o => o.type === "group");
                if (seats.length === 0) return false;
                seats.sort((a, b) => {
                    const rowY = Math.round(a.top / 10) * 10;
                    const rowY2 = Math.round(b.top / 10) * 10;
                    if (rowY === rowY2) return a.left - b.left;
                    return rowY - rowY2;
                });
                const rows = this.groupSeatsByRow(seats);
                const rowCount = Object.keys(rows).length;
                var ddlrow = document.getElementById("ddlrow");
                var txtrowlbl = document.getElementById("txtrowlbl");
                if (rowCount > 1) {
                    txtrowlbl.style.display = "none";
                    ddlrow.style.display = "block";
                } else {
                    txtrowlbl.style.display = "block";
                    ddlrow.style.display = "none";
                }
            }
            return hasSeat;
        }
        return false;
    },

    isRectangleSelected(activeObject) {
        if (!activeObject) return false;
        if (activeObject.type === "rect" && activeObject.objectType === "rectangle") return true;
        if (activeObject.type === "activeSelection") {
            return activeObject._objects.some(obj => obj.objectType === "rectangle");
        }
        return false;
    },

    isGeneralSelected(activeObject) {
        if (!activeObject) return false;
        if (activeObject.type === "rect" && activeObject.objectType === "genrectangle") return true;
        return false;
    },

    toggleRectangleDropdown(show) {
        const container = document.getElementById("ddlrectcontainer");
        if (container) container.style.display = show ? "block" : "none";
    },

    toggleSeatDropdown(show) {
        const rowlbl = document.getElementById("divrowlabel");
        const seatlbl = document.getElementById("divseatlabel");
        const direction = document.getElementById("divdirection");
        const btnapply = document.getElementById("btnapply");
        const seatcount = document.getElementById("seatcnt");
        const divcustomseat = document.getElementById("divcustomseat");
        const divcustomrow = document.getElementById("divcustomrow");
        const btnCustomizeRows = document.getElementById("btnCustomizeRows");
        rowlbl.style.display = show ? "block" : "none";
        seatlbl.style.display = show ? "block" : "none";
        direction.style.display = show ? "block" : "none";
        btnapply.style.display = show ? "block" : "none";
        seatcount.style.display = show ? "block" : "none";
        if (btnCustomizeRows) btnCustomizeRows.style.display = show ? "block" : "none";
        if (divcustomseat) divcustomseat.style.display = show ? "block" : "none";
        if (divcustomrow) divcustomrow.style.display = show ? "block" : "none";
    },

    toggleGeneralProps(show) {
        const rectlbl = document.getElementById("divgenerallbl");
        const capacity = document.getElementById("divcapacity");
        if (rectlbl) rectlbl.style.display = show ? "block" : "none";
        if (capacity) capacity.style.display = show ? "block" : "none";
    },

    validateLabels(canvas) {
        let invalidObjects = [];
        canvas.getObjects().forEach(obj => {
            if (obj.objectType === "guide") return;
            if ((obj.objectType === "seat" || obj.type === "group") && (!obj.seatLabel || obj.seatLabel.trim() === "" || !obj.rowLabel || obj.rowLabel.trim() === "")) {
                invalidObjects.push(obj);
            }
        });
        return invalidObjects;
    },

    isCategorized(canvas) {
        let invalidObjects = [];
        canvas.getObjects().forEach(obj => {
            if (obj.objectType === "guide") return;
            if ((obj.objectType === "seat" || obj.type === "group") && (!obj.categoryId || obj.categoryId.trim() === "")) {
                invalidObjects.push(obj);
            }
        });
        return invalidObjects;
    },

    checkDuplicateRowLabels(canvas) {
        const rowLabels = {};
        const duplicates = [];
        const allObjects = canvas.getObjects();
        allObjects.forEach(obj => {
            if (obj.objectType === "seat" && obj.rowLabel && obj.rowLabel.trim() !== "") {
                const label = obj.rowLabel.trim();
                if (!rowLabels[label]) rowLabels[label] = [];
                rowLabels[label].push(obj);
            }
            if (obj.isRowLabel === true && obj.text && obj.text.trim() !== "") {
                const label = obj.text.trim();
                if (!rowLabels[label]) rowLabels[label] = [];
                rowLabels[label].push(obj);
            }
        });
        Object.keys(rowLabels).forEach(label => {
            if (rowLabels[label].length > 1) duplicates.push(...rowLabels[label]);
        });
        return duplicates;
    },

    highlightInvalidObjects(objects, canvas) {
        objects.forEach(obj => {
            obj.set({ stroke: "red", strokeWidth: 3 });
        });
        canvas.requestRenderAll();
    },

    showValidation(canvas) {
        var divvalid = document.getElementById("divvalidate");
        var lblvalidation = document.getElementById("lblvalidation");
        var catvalidtion = document.getElementById("catvalidation");
        divvalid.style.display = "block";
        lblvalidation.style.display = "block";
        catvalidation.style.display = "block";
        const invalid = this.validateLabels(canvas);
        const uncategorized = this.isCategorized(canvas);
        if (invalid.length > 0) {
            lblvalidation.innerText = invalid.length + " unlabeled objects";
            lblvalidation.style.color = "red";
        } else {
            lblvalidation.innerText = "All objects are labeled";
            lblvalidation.style.color = "green";
        }
        if (uncategorized.length > 0) {
            catvalidation.innerText = uncategorized.length + " uncategorized objects";
            catvalidation.style.color = "red";
        } else {
            catvalidation.innerText = "All objects are categorized";
            catvalidation.style.color = "green";
        }
    },

    disableValidation() {
        var divvalid = document.getElementById("divvalidate");
        var lblvalidation = document.getElementById("lblvalidation");
        var catvalidation = document.getElementById("catvalidation");
        divvalid.style.display = "none";
        lblvalidation.style.display = "none";
        catvalidation.style.display = "none";
    },

    createMultipleRowPreview(canvas, pointer) {
        this.clearMultipleRowPreview(canvas);
        if (this.firstRowSeatCount === 0) return;
        const spacing = this.seatSpacing || 20;
        const rowLabel = "";
        let offsetX = 0, offsetY = 0;
        if (this.firstRowDirection === "horizontal") {
            offsetY = pointer.y - this.rowStart.y;
        } else {
            offsetX = pointer.x - this.rowStart.x;
        }
        for (let i = 0; i < this.firstRowSeatCount; i++) {
            const baseX = this.rowStart.x + (this.firstRowDirection === "horizontal" ? i * spacing : 0);
            const baseY = this.rowStart.y + (this.firstRowDirection === "vertical" ? i * spacing : 0);
            const x = baseX + offsetX;
            const y = baseY + offsetY;
            const seat = new fabric.Circle({
                left: x, top: y, radius: 8, fill: "rgba(255, 255, 255, 0.7)",
                originX: "center", originY: "center", selectable: false, evented: false,
                stroke: "blue", strokeWidth: 1
            });
            seat.isMultiRowPreview = true;
            this.previewSeats.push(seat);
            canvas.add(seat);
        }
        if (this.firstRowDirection === "horizontal") {
            const startX = this.rowStart.x + offsetX;
            const endX = startX + (this.firstRowSeatCount - 1) * spacing;
            const y = this.rowStart.y + offsetY;
            this.previewLine = new fabric.Line([startX, y, endX, y], {
                stroke: "#4CAF50", strokeDashArray: [5, 5], strokeWidth: 2,
                selectable: false, evented: false
            });
        } else {
            const x = this.rowStart.x + offsetX;
            const startY = this.rowStart.y + offsetY;
            const endY = startY + (this.firstRowSeatCount - 1) * spacing;
            this.previewLine = new fabric.Line([x, startY, x, endY], {
                stroke: "#4CAF50", strokeDashArray: [5, 5], strokeWidth: 2,
                selectable: false, evented: false
            });
        }
        canvas.add(this.previewLine);
    },

    createRowFromPreview(canvas) {
        if (!this.previewSeats || this.previewSeats.length === 0) return;
        const spacing = this.seatSpacing || 20;
        const count = this.previewSeats.length;
        const rowLabel = "";
        const rowId = `row-${rowLabel}-${Date.now()}`;
        isBulkAdding = true;
        for (let i = 0; i < count; i++) {
            const previewSeat = this.previewSeats[i];
            const x = previewSeat.left;
            const y = previewSeat.top;
            const seatLabel = (i + 1).toString();
            const seatId = rowLabel ? `${rowLabel}${seatLabel}` : `Seat-${this.seatCounter++}`;
            this.createSeat(canvas, x, y, seatLabel, seatId, rowLabel, rowId);
        }
        isBulkAdding = false;
        this.firstRowStart = { x: this.rowStart.x, y: this.rowStart.y };
        this.autoIncrementRowLabel();
    },

    createMultipleRowFromPreview(canvas) {
        if (this.firstRowSeatCount === 0) return;
        const spacing = this.seatSpacing || 20;
        const rowLabel = "";
        const rowId = `row-${rowLabel}-${Date.now()}`;
        isBulkAdding = true;
        let offsetX = 0, offsetY = 0;
        if (this.firstRowDirection === "horizontal") {
            offsetY = this.rowStart.y - this.firstRowStart.y;
        } else {
            offsetX = this.rowStart.x - this.firstRowStart.x;
        }
        for (let i = 0; i < this.firstRowSeatCount; i++) {
            const baseX = this.firstRowStart.x + (this.firstRowDirection === "horizontal" ? i * spacing : 0);
            const baseY = this.firstRowStart.y + (this.firstRowDirection === "vertical" ? i * spacing : 0);
            const x = baseX + offsetX;
            const y = baseY + offsetY;
            const seatLabel = (i + 1).toString();
            const seatId = rowLabel ? `${rowLabel}${seatLabel}` : `Seat-${this.seatCounter++}`;
            this.createSeat(canvas, x, y, seatLabel, seatId, rowLabel, rowId);
        }
        isBulkAdding = false;
        this.rowStart = { x: this.rowStart.x, y: this.rowStart.y };
        this.autoIncrementRowLabel();
    },

    autoIncrementRowLabel() {
        const txtRowLbl = document.getElementById("txtrowlbl");
        if (!txtRowLbl) return;
        const currentValue = txtRowLbl.value;
        const match = currentValue.match(/^(.*?)(\d+)$/);
        if (match) {
            const prefix = match[1];
            const number = parseInt(match[2]);
            txtRowLbl.value = prefix + (number + 1);
        } else if (currentValue.match(/^[A-Z]$/i)) {
            const charCode = currentValue.charCodeAt(0);
            txtRowLbl.value = String.fromCharCode(charCode + 1);
        }
    },

    showNextRowGuide(canvas) {
        if (this.firstRowSeatCount === 0 || !this.firstRowStart) return;
        if (this.nextRowGuide) canvas.remove(this.nextRowGuide);
        const spacing = this.seatSpacing || 20;
        const rowGap = this.rowGap || 30;
        if (this.firstRowDirection === "horizontal") {
            const nextY = this.rowStart.y + rowGap;
            this.nextRowGuide = new fabric.Line([0, nextY, canvas.width, nextY], {
                stroke: "#FF9800", strokeDashArray: [5, 5], strokeWidth: 1,
                selectable: false, evented: false, opacity: 0.5
            });
        } else {
            const nextX = this.rowStart.x + rowGap;
            this.nextRowGuide = new fabric.Line([nextX, 0, nextX, canvas.height], {
                stroke: "#FF9800", strokeDashArray: [5, 5], strokeWidth: 1,
                selectable: false, evented: false, opacity: 0.5
            });
        }
        canvas.add(this.nextRowGuide);
        canvas.sendToBack(this.nextRowGuide);
    },

    clearMultipleRowPreview(canvas) {
        this.previewSeats.forEach(seat => {
            if (seat.isMultiRowPreview) canvas.remove(seat);
        });
        this.previewSeats = this.previewSeats.filter(seat => !seat.isMultiRowPreview);
        if (this.previewLine) {
            canvas.remove(this.previewLine);
            this.previewLine = null;
        }
    },

    clearAllPreviews(canvas) {
        if (this.previewSeats) {
            this.previewSeats.forEach(s => {
                if (canvas && s && canvas.contains(s)) canvas.remove(s);
            });
        }
        this.previewSeats = [];
        if (this.previewLine && canvas && canvas.contains(this.previewLine)) {
            canvas.remove(this.previewLine);
            this.previewLine = null;
        }
        if (this.nextRowGuide && canvas && canvas.contains(this.nextRowGuide)) {
            canvas.remove(this.nextRowGuide);
            this.nextRowGuide = null;
        }
        this.clearAlignmentGuides(canvas);
        this.clearRowGuide(canvas);
        this.multiRowPreviewRows = [];
        const tooltip = document.getElementById("seatTooltip");
        if (tooltip) tooltip.style.display = "none";
    },

    createRowAtPosition(canvas, pointer) {
        const spacing = this.seatSpacing || 20;
        for (let i = 0; i < this.firstRowSeatCount; i++) {
            const x = this.rowDirection === "horizontal" ? pointer.x + i * spacing : pointer.x;
            const y = this.rowDirection === "vertical" ? pointer.y + i * spacing : pointer.y;
            this.createSeat(canvas, x, y, i + 1);
        }
        canvas.renderAll();
    },

    createRowAt(canvas, pos) {
        const spacing = this.seatSpacing || 25;
        const direction = this.firstRowDirection || this.rowDirection;
        const startX = this.firstRowStartX;
        const startY = pos.y;
        for (let i = 0; i < this.firstRowSeatCount; i++) {
            let x = startX;
            let y = startY;
            if (direction === "horizontal") x = startX + i * spacing;
            else y = startY + i * spacing;
            this.createSeat(canvas, x, y, i + 1);
        }
    },

    createNextRow(canvas, pointer) {
        const spacing = this.seatSpacing || 25;
        const startX = this.rowStart.x;
        const startY = this.rowStart.y + this.rowGap;
        const newStart = { x: startX, y: startY };
        this.createRowAt(canvas, newStart);
    },

    updateFirstRowPreview(canvas, pointer, opt) {
        if (this.previewLine) {
            canvas.remove(this.previewLine);
            this.previewLine = null;
        }
        this.previewSeats.forEach(s => canvas.remove(s));
        this.previewSeats = [];
        const dx = Math.abs(pointer.x - this.rowStart.x);
        const dy = Math.abs(pointer.y - this.rowStart.y);
        this.rowDirection = dx > dy ? "horizontal" : "vertical";
        const spacing = this.seatSpacing || 22;
        const dist = this.rowDirection === "horizontal" ? dx : dy;
        const seatCount = Math.max(1, Math.floor(dist / spacing) + 1);
        this.firstRowSeatCount = seatCount;
        const tooltip = document.getElementById("seatTooltip");
        if (tooltip && opt && opt.e) {
            tooltip.textContent = `Seats: ${seatCount}`;
            tooltip.style.left = (opt.e.clientX + 10) + "px";
            tooltip.style.top = (opt.e.clientY + 10) + "px";
            tooltip.style.display = "block";
        }
        this.updateFullHeightRowGuides(canvas, this.rowStart, this.rowDirection, seatCount);
        this.previewLine = new fabric.Line([
            this.rowStart.x, this.rowStart.y,
            this.rowDirection === "horizontal" ? this.rowStart.x + (this.firstRowSeatCount - 1) * spacing : this.rowStart.x,
            this.rowDirection === "vertical" ? this.rowStart.y + (this.firstRowSeatCount - 1) * spacing : this.rowStart.y
        ], { stroke: "#2196F3", strokeDashArray: [5, 5], selectable: false, evented: false });
        canvas.add(this.previewLine);
        for (let i = 0; i < this.firstRowSeatCount; i++) {
            const x = this.rowDirection === "horizontal" ? this.rowStart.x + i * spacing : this.rowStart.x;
            const y = this.rowDirection === "vertical" ? this.rowStart.y + i * spacing : this.rowStart.y;
            const seat = new fabric.Circle({
                left: x, top: y, radius: 8, fill: "rgba(255, 255, 255, 0.7)",
                stroke: "black", selectable: false, evented: false,
                originX: "center", originY: "center"
            });
            this.previewSeats.push(seat);
            canvas.add(seat);
        }
        canvas.renderAll();
    },

    createPreviewRow(canvas, rowY, rowIndex, opt) {
        const spacing = this.seatSpacing || 22;
        const seatCount = this.firstRowSeatCount;
        const angle = this.firstRowAngle || this.rowAngle || 0;
        const startX = this.firstRowStartX || this.rowStart.x;
        const startY = this.firstRowStartY || this.rowStart.y;
        if (seatCount === 0) return;
        const verticalOffset = rowY - startY;
        let rowStartX = startX;
        let rowStartY = rowY;
        if (angle !== 0 && angle !== 180) {
            const perpAngle = angle + 90;
            const perpOffset = verticalOffset / Math.sin(perpAngle * Math.PI / 180);
            rowStartX = startX + Math.cos(perpAngle * Math.PI / 180) * perpOffset;
            rowStartY = startY + Math.sin(perpAngle * Math.PI / 180) * perpOffset;
        }
        const tooltip = document.getElementById("rowTooltip");
        if (tooltip && opt && opt.e) {
            tooltip.style.position = "absolute";
            tooltip.textContent = (rowIndex + 1) + ' x ' + seatCount;
            tooltip.style.left = (opt.e.clientX + 10) + "px";
            tooltip.style.top = (opt.e.clientY + 10) + "px";
            tooltip.style.display = "block";
        }
        for (let i = 0; i < seatCount; i++) {
            const seatDistance = i * spacing;
            const x = rowStartX + Math.cos(angle * Math.PI / 180) * seatDistance;
            const y = rowStartY + Math.sin(angle * Math.PI / 180) * seatDistance;
            const seat = new fabric.Circle({
                left: x, top: y, radius: 8, fill: "rgba(255, 255, 255, 0.7)",
                originX: "center", originY: "center", selectable: false, evented: false,
                stroke: "blue", strokeWidth: 1
            });
            seat.isPreviewRow = true;
            seat.rowIndex = rowIndex;
            seat.seatIndex = i;
            this.previewSeats.push(seat);
            canvas.add(seat);
        }
        const endX = rowStartX + Math.cos(angle * Math.PI / 180) * ((seatCount - 1) * spacing);
        const endY = rowStartY + Math.sin(angle * Math.PI / 180) * ((seatCount - 1) * spacing);
        const line = new fabric.Line([rowStartX, rowStartY, endX, endY], {
            stroke: "#4CAF50", strokeDashArray: [5, 5], strokeWidth: 1,
            selectable: false, evented: false, opacity: 0.7
        });
        line.isPreviewRow = true;
        line.rowIndex = rowIndex;
        this.previewSeats.push(line);
        canvas.add(line);
    },

    createActualRowFromPreview(canvas) {
        if (this.firstRowSeatCount === 0) return;
        const spacing = this.seatSpacing || 22;
        const rowLabel = "";
        const rowId = `row-${rowLabel}-${Date.now()}`;
        const angle = this.firstRowAngle || this.rowAngle || 0;
        isBulkAdding = true;
        const useAngledPositioning = (angle !== 0 && angle !== 90 && angle !== 180 && angle !== 270);
        if (useAngledPositioning) {
            for (let i = 0; i < this.firstRowSeatCount; i++) {
                const seatDistance = i * spacing;
                const x = this.rowStart.x + Math.cos(angle * Math.PI / 180) * seatDistance;
                const y = this.rowStart.y + Math.sin(angle * Math.PI / 180) * seatDistance;
                const seatLabel = (i + 1).toString();
                const seatId = rowLabel ? `${rowLabel}${seatLabel}` : `Seat-${this.seatCounter++}`;
                this.createSeat(canvas, x, y, seatLabel, seatId, rowLabel, rowId);
            }
        } else {
            const isHorizontal = (angle === 0 || angle === 180);
            for (let i = 0; i < this.firstRowSeatCount; i++) {
                let x = this.rowStart.x;
                let y = this.rowStart.y;
                if (isHorizontal) {
                    x = this.rowStart.x + i * spacing;
                    if (angle === 180) x = this.rowStart.x - i * spacing;
                } else {
                    y = this.rowStart.y + i * spacing;
                    if (angle === 270) y = this.rowStart.y - i * spacing;
                }
                const seatLabel = (i + 1).toString();
                const seatId = rowLabel ? `${rowLabel}${seatLabel}` : `Seat-${this.seatCounter++}`;
                this.createSeat(canvas, x, y, seatLabel, seatId, rowLabel, rowId);
            }
        }
        isBulkAdding = false;
        this.rowAngle = angle;
        this.firstRowAngle = angle;
        this.autoIncrementRowLabel();
        saveState(canvas);
    },

    createActualRowsFromPreviews(canvas) {
        if (this.firstRowSeatCount === 0) return;
        const spacing = this.seatSpacing || 22;
        const rowGap = this.rowGap || 30;
        const angle = this.firstRowAngle || 0;
        const startX = this.firstRowStartX || this.rowStart.x;
        const startY = this.firstRowStartY || this.rowStart.y;
        const maxRowIndex = Math.max(0, ...this.previewSeats.filter(s => s.isPreviewRow && s.rowIndex).map(s => s.rowIndex));
        if (maxRowIndex === 0) return;
        isBulkAdding = true;
        let finalRowStartX = startX;
        let finalRowStartY = startY;
        for (let r = 1; r <= maxRowIndex; r++) {
            const rowY = startY + r * rowGap;
            const rowLabel = "";
            const rowId = `row-${rowLabel}-${Date.now()}-${r}`;
            let rowStartX = startX;
            let rowStartY = rowY;
            if (angle !== 0 && angle !== 180) {
                const perpAngle = angle + 90;
                const verticalOffset = rowY - startY;
                const perpOffset = verticalOffset / Math.sin(perpAngle * Math.PI / 180);
                rowStartX = startX + Math.cos(perpAngle * Math.PI / 180) * perpOffset;
                rowStartY = startY + Math.sin(perpAngle * Math.PI / 180) * perpOffset;
            }
            finalRowStartX = rowStartX;
            finalRowStartY = rowStartY;
            for (let i = 0; i < this.firstRowSeatCount; i++) {
                const seatDistance = i * spacing;
                const x = rowStartX + Math.cos(angle * Math.PI / 180) * seatDistance;
                const y = rowStartY + Math.sin(angle * Math.PI / 180) * seatDistance;
                const seatLabel = (i + 1).toString();
                const seatId = rowLabel ? `${rowLabel}${seatLabel}` : `Seat-${this.seatCounter++}`;
                this.createSeat(canvas, x, y, seatLabel, seatId, rowLabel, rowId);
            }
            this.autoIncrementRowLabel();
        }
        isBulkAdding = false;
        this.lastRowPosition = { x: finalRowStartX, y: finalRowStartY, angle: angle };
        saveState(canvas);
    },

    clearGeneratedRows(canvas) {
        if (!this.previewSeats) return;
        const previewRowObjects = this.previewSeats.filter(s => s.isPreviewRow);
        previewRowObjects.forEach(obj => {
            if (canvas.contains(obj)) canvas.remove(obj);
        });
        this.previewSeats = this.previewSeats.filter(s => !s.isPreviewRow);
        this.multiRowPreviewRows = [];
    },

    applyGeneralCategoryLabel(canvasId) {
        const canvas = this.canvases[canvasId];
        const active = canvas.getActiveObject();
        if (!active) {
            showNotification("Please select a rectangle to label");
            return;
        }
        let rect = null;
        if (active.type === "activeSelection") {
            const rectangles = active._objects.filter(obj => obj.objectType === "genrectangle");
            if (rectangles.length > 1) {
                showNotification("Please select only one rectangle at a time for labeling");
                return;
            }
            if (rectangles.length === 0) {
                showNotification("No rectangle found in selection");
                return;
            }
            rect = rectangles[0];
        } else if (active.type === "rect" && active.objectType === "genrectangle") {
            rect = active;
        } else {
            showNotification("Please select a rectangle (not other objects)");
            return;
        }
        const label = document.getElementById("txtrectlbl").value;
        const capacity = document.getElementById("txtcapacity").value;
        if (!label || label.trim() === "") {
            showNotification("Please enter a label");
            return;
        }
        if (rect.generalLabel && rect.labelTextId) {
            const existingLabel = canvas.getObjects().find(obj => obj.id === rect.labelTextId || obj === rect.labelText);
            if (existingLabel) canvas.remove(existingLabel);
            rect.labelText = null;
            rect.labelTextId = null;
        }
        const fontSize = Math.min(rect.height * 0.3, rect.width * 0.2, 16);
        const labelId = `label-${rect.rectangleId}-${Date.now()}`;
        const labelText = new fabric.Text(label, {
            fontSize: Math.max(fontSize, 12), fontWeight: "bold", fill: "white",
            originX: "center", originY: "center",
            left: rect.left + rect.width / 2, top: rect.top + rect.height / 2,
            selectable: false, evented: false, text: label,
            rectangleId: rect.rectangleId, isRectangleLabel: true,
            textAlign: 'center', id: labelId
        });
        rect.generalLabel = label;
        rect.labelTextId = labelId;
        rect.rectangleLabel = label;
        rect.capacity = capacity ? parseInt(capacity) : 0;
        rect.objectType = "genrectangle";
        labelText.generalLabel = label;
        rect.set('labelTextId', labelId);
        rect.set('rectangleLabel', label);
        rect.set('capacity', rect.capacity);
        rect.set('objectType', rect.objectType);
        rect.set('generalLabel', label);
        labelText.set('generalLabel', label);
        rect.currentCount = 0;
        rect.set('currentCount', 0);
        canvas.add(labelText);
        labelText.set('fill', getContrastColor(rect.categoryId));
        canvas.renderAll();
        saveState(canvas);
        return true;
    },

    handleGenRectangleSelection(canvasId, rectangle, mouseEvent) {
        const canvas = this.canvases[canvasId];
        const rectangleId = rectangle.rectangleId || rectangle.get("rectangleId");
        const category = rectangle.categoryName || rectangle.get("categoryName") || "General";
        const label = rectangle.generalLabel || rectangle.get("generalLabel") || "General Area";
        const capacity = rectangle.capacity || rectangle.get("capacity") || 0;
        const color = rectangle.categoryId || rectangle.fill || "#f0f0f0";
        this.showGASelectionPopup(canvasId, rectangle, mouseEvent);
    },

    showGASelectionPopup(canvasId, rectangle, mouseEvent) {
        const canvas = this.canvases[canvasId];
        const rectangleId = rectangle.rectangleId || rectangle.get("rectangleId");
        const category = rectangle.categoryName || rectangle.get("categoryName") || "General";
        const label = rectangle.generalLabel || rectangle.get("generalLabel") || "General Area";
        const capacity = rectangle.capacity || rectangle.get("capacity") || 0;
        const currentCount = rectangle.currentCount || rectangle.get("currentCount") || 0;
        const maxAvailable = capacity;
        if (!canvas.selectedGAAreas) canvas.selectedGAAreas = [];
        const existingIndex = canvas.selectedGAAreas.findIndex(area => area.id === rectangleId);
        document.getElementById("categoryInfo").innerHTML = `<strong>${label}</strong><br>`;
        let ticketCount = 0;
        if (parseInt(currentCount) > 0) ticketCount = ticketCount + parseInt(currentCount);
        const ticketCountElement = document.getElementById("seatCount");
        ticketCountElement.textContent = ticketCount;
        if (availableForThisArea <= 0) {
            document.getElementById("increaseSeats").disabled = true;
            document.getElementById("decreaseSeats").disabled = true;
        } else {
            document.getElementById("increaseSeats").disabled = false;
            document.getElementById("decreaseSeats").disabled = false;
        }
        const increaseBtn = document.getElementById("increaseSeats");
        const decreaseBtn = document.getElementById("decreaseSeats");
        const addBtn = document.getElementById("addSeatsBtn");
        increaseBtn.replaceWith(increaseBtn.cloneNode(true));
        decreaseBtn.replaceWith(decreaseBtn.cloneNode(true));
        addBtn.replaceWith(addBtn.cloneNode(true));
        const newIncreaseBtn = document.getElementById("increaseSeats");
        const newDecreaseBtn = document.getElementById("decreaseSeats");
        const newAddBtn = document.getElementById("addSeatsBtn");
        const cancelbtn = document.getElementById("cancelbtn");
        newIncreaseBtn.onclick = () => {
            if (ticketCount < maxAvailable) {
                ticketCount++;
                ticketCountElement.textContent = ticketCount;
            }
        };
        newDecreaseBtn.onclick = () => {
            if (ticketCount >= 1) {
                ticketCount--;
                ticketCountElement.textContent = ticketCount;
            }
        };
        newAddBtn.onclick = () => {
            if (ticketCount === 0) {
                if (existingIndex >= 0) canvas.selectedGAAreas.splice(existingIndex, 1);
                rectangle.set({ fill: rectangle.categoryId || rectangle.fill || "#f2fd58", stroke: "black", strokeWidth: 1 });
                this.removeGASelectionIndicator(canvas, rectangle);
                this.updateRectangleLabelWithCount(canvas, rectangle, 0);
            } else {
                if (existingIndex >= 0) {
                    canvas.selectedGAAreas[existingIndex].ticketCount = ticketCount;
                } else {
                    canvas.selectedGAAreas.push({ id: rectangleId, label: label, categoryName: category, ticketCount: ticketCount, capacity: capacity });
                    rectangle.set({ fill: rectangle.categoryId || rectangle.fill || "#f2fd58", stroke: "", strokeWidth: 2 });
                }
                this.updateGASelectionIndicator(canvas, rectangle, ticketCount);
                this.updateRectangleLabelWithCount(canvas, rectangle, ticketCount);
            }
            canvas.renderAll();
            closeSeatPopup();
            this.sendGASelectionToParent(canvas);
        };
        cancelbtn.onclick = () => {
            this.updateRectangleLabelWithCount(canvas, rectangle, 0);
            canvas.selectedGAAreas = [];
            canvas.renderAll();
            closeSeatPopup();
            this.sendGASelectionToParent(canvas);
        };
        this.positionPopupNearMouse(mouseEvent);
        document.getElementById("seatAdjustmentPopup").style.display = "block";
    },

    showGAAdjustmentPopup(canvasId, rectangle, existingIndex, mouseEvent) {
        const canvas = this.canvases[canvasId];
        const rectangleId = rectangle.rectangleId || rectangle.get("rectangleId");
        const selectedArea = canvas.selectedGAAreas[existingIndex];
        const category = rectangle.categoryName || rectangle.get("categoryName") || "General";
        const label = rectangle.generalLabel || rectangle.get("generalLabel") || "General Area";
        const capacity = rectangle.capacity || rectangle.get("capacity") || 0;
        const availableForThisArea = capacity;
        document.getElementById("popupTitle").textContent = `Adjust ${label} Tickets`;
        document.getElementById("categoryInfo").innerHTML = `<strong>Area:</strong> ${label}<br><strong>Category:</strong> ${category}<br><strong>Currently Selected:</strong> ${selectedArea.ticketCount} tickets<br><strong>Maximum:</strong> ${availableForThisArea} tickets`;
        let ticketCount = selectedArea.ticketCount;
        const ticketCountElement = document.getElementById("seatCount");
        ticketCountElement.textContent = ticketCount;
        const maxSeatsMsg = document.getElementById("maxSeatsMsg");
        maxSeatsMsg.textContent = `Maximum: ${availableForThisArea} tickets`;
        maxSeatsMsg.style.color = "#666";
        const increaseBtn = document.getElementById("increaseSeats");
        const decreaseBtn = document.getElementById("decreaseSeats");
        const addBtn = document.getElementById("addSeatsBtn");
        increaseBtn.replaceWith(increaseBtn.cloneNode(true));
        decreaseBtn.replaceWith(decreaseBtn.cloneNode(true));
        addBtn.replaceWith(addBtn.cloneNode(true));
        const newIncreaseBtn = document.getElementById("increaseSeats");
        const newDecreaseBtn = document.getElementById("decreaseSeats");
        const newAddBtn = document.getElementById("addSeatsBtn");
        newAddBtn.textContent = "Update Selection";
        newIncreaseBtn.onclick = () => {
            if (ticketCount < availableForThisArea) {
                ticketCount++;
                ticketCountElement.textContent = ticketCount;
            }
        };
        newDecreaseBtn.onclick = () => {
            if (ticketCount > 0) {
                ticketCount--;
                ticketCountElement.textContent = ticketCount;
            }
        };
        newAddBtn.onclick = () => {
            if (ticketCount === 0) {
                canvas.selectedGAAreas.splice(existingIndex, 1);
                rectangle.set({ fill: rectangle.categoryId || "#f2fd58", stroke: "black", strokeWidth: 1 });
                this.removeGASelectionIndicator(canvas, rectangle);
                this.updateRectangleLabelWithCount(canvas, rectangle, 0);
            } else {
                selectedArea.ticketCount = ticketCount;
                this.updateGASelectionIndicator(canvas, rectangle, ticketCount);
                this.updateRectangleLabelWithCount(canvas, rectangle, ticketCount);
            }
            canvas.renderAll();
            closeSeatPopup();
            this.sendGASelectionToParent(canvas);
        };
        this.positionPopupNearMouse(mouseEvent);
        document.getElementById("seatAdjustmentPopup").style.display = "block";
    },

    lightenColor(color, factor) {
        if (!color || typeof color !== 'string') return color;
        if (color.startsWith('#')) {
            const num = parseInt(color.slice(1), 16);
            const r = Math.min(255, (num >> 16) + 255 * factor);
            const g = Math.min(255, ((num >> 8) & 0x00FF) + 255 * factor);
            const b = Math.min(255, (num & 0x0000FF) + 255 * factor);
            return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
        }
        if (color.startsWith('rgb')) {
            const matches = color.match(/\d+/g);
            if (matches) {
                const r = Math.min(255, parseInt(matches[0]) + 255 * factor);
                const g = Math.min(255, parseInt(matches[1]) + 255 * factor);
                const b = Math.min(255, parseInt(matches[2]) + 255 * factor);
                const a = matches[3] ? parseFloat(matches[3]) : 1;
                return `rgba(${r}, ${g}, ${b}, ${a})`;
            }
        }
        return color;
    },

    addGASelectionIndicator(canvas, rectangle, count) {
        this.removeGASelectionIndicator(canvas, rectangle);
        const rectBounds = rectangle.getBoundingRect();
        const indicatorId = `ga-indicator-${rectangle.rectangleId}`;
        const indicator = new fabric.Text(`${count}`, {
            left: rectBounds.left + rectBounds.width - 15, top: rectBounds.top + 5,
            fontSize: 12, fontWeight: 'bold', fill: '#4CAF50', backgroundColor: 'white',
            padding: 3, selectable: false, evented: false, id: indicatorId,
            originX: 'center', originY: 'center'
        });
        rectangle.selectionIndicatorId = indicatorId;
        canvas.add(indicator);
        canvas.bringToFront(indicator);
    },

    updateGASelectionIndicator(canvas, rectangle, count) {
        this.removeGASelectionIndicator(canvas, rectangle);
    },

    removeGASelectionIndicator(canvas, rectangle) {
        if (rectangle.selectionIndicatorId) {
            const indicator = canvas.getObjects().find(obj => obj.id === rectangle.selectionIndicatorId);
            if (indicator) canvas.remove(indicator);
            rectangle.selectionIndicatorId = null;
        }
    },

    positionPopupNearMouse(mouseEvent) {
        const popup = document.getElementById('seatAdjustmentPopup');
        const content = popup.querySelector('.modal-content');
        const x = mouseEvent.clientX;
        const y = mouseEvent.clientY;
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        const popupWidth = 300;
        const popupHeight = 300;
        let left = x + 120;
        let top = y - popupHeight / 2;
        if (left + popupWidth > viewportWidth) left = x - popupWidth - 20;
        if (top < 20) top = 20;
        if (top + popupHeight > viewportHeight - 20) top = viewportHeight - popupHeight - 20;
        content.style.position = 'fixed';
        content.style.left = left + 'px';
        content.style.top = top + 'px';
        content.style.margin = '0';
    },

    sendGASelectionToParent(canvas) {
        const allSelectedSeats = canvas.selectedSeats || [];
        const selectedGAAreas = canvas.selectedGAAreas || [];
        const allSelections = {
            seats: allSelectedSeats,
            gaAreas: selectedGAAreas,
            totalTickets: allSelectedSeats.length + selectedGAAreas.reduce((sum, area) => sum + area.ticketCount, 0)
        };
        window.parent.postMessage({ type: "GAseatsSelected", selections: allSelections }, "*");
    },

    clearSelectedSeats(canvasId) {
        const canvas = this.canvases[canvasId];
        if (canvas && canvas.selectedSeats) canvas.selectedSeats = [];
        if (canvas && canvas.selectedGAAreas) {
            canvas.selectedGAAreas.forEach(area => {
                const rectangle = canvas.getObjects().find(obj => obj.rectangleId === area.id && obj.objectType === 'genrectangle');
                if (rectangle) {
                    rectangle.set({ fill: rectangle.categoryId || "#f2fd58", stroke: "black", strokeWidth: 1 });
                    this.removeGASelectionIndicator(canvas, rectangle);
                }
            });
            canvas.selectedGAAreas = [];
        }
        canvas.forEachObject(obj => {
            if (obj.type === 'group' && obj.textObj) {
                if (obj.textObj.text === "✔") {
                    obj.textObj.set({ text: "", fontWeight: "normal", fontSize: 10 });
                    obj.set("isSelected", false);
                    obj.isSelected = false;
                }
            }
        });
        canvas.renderAll();
        this.sendGASelectionToParent(canvas);
    },

    updateRectangleLabelWithCount(canvas, rectangle, count) {
        const existingLabel = canvas.getObjects().find(obj => (obj.id === rectangle.labelTextId && obj.type === 'text') || (obj.rectangleId === rectangle.rectangleId && obj.type === 'text'));
        if (existingLabel && existingLabel.type === 'text') {
            canvas.remove(existingLabel);
            rectangle.labelText = null;
            rectangle.labelTextId = null;
        }
        if (count === 0) {
            const baseLabel = rectangle.baseLabel || rectangle.generalLabel || rectangle.get('generalLabel') || '';
            if (baseLabel) {
                const fontSize = Math.min(rectangle.height * 0.3, rectangle.width * 0.2, 16);
                const finalFontSize = Math.max(fontSize, 12);
                const labelId = `label-${rectangle.rectangleId}-${Date.now()}`;
                const centerX = rectangle.left + rectangle.width / 2;
                const centerY = rectangle.top + rectangle.height / 2;
                const labelText = new fabric.Text(baseLabel, {
                    fontSize: finalFontSize, fontWeight: "bold",
                    fill: getContrastColor(rectangle.categoryId || rectangle.fill || "#000000"),
                    originX: "center", originY: "center", left: centerX, top: centerY,
                    selectable: false, evented: false, text: baseLabel,
                    rectangleId: rectangle.rectangleId, isRectangleLabel: true,
                    textAlign: 'center', id: labelId, baseText: baseLabel
                });
                rectangle.labelText = labelText;
                rectangle.labelTextId = labelId;
                rectangle.set('labelTextId', labelId);
                canvas.add(labelText);
                canvas.bringToFront(labelText);
            }
            rectangle.currentCount = 0;
            rectangle.set('currentCount', 0);
            return;
        }
        const fontSize = Math.min(rectangle.height * 0.4, rectangle.width * 0.3, 24);
        const finalFontSize = Math.max(fontSize, 12);
        const labelId = `label-${rectangle.rectangleId}-${Date.now()}`;
        const centerX = rectangle.left + rectangle.width / 2;
        const centerY = rectangle.top + rectangle.height / 2;
        const countText = count.toString();
        const labelText = new fabric.Text(countText, {
            fontSize: finalFontSize, fontWeight: "bold",
            fill: getContrastColor(rectangle.categoryId || rectangle.fill || "#000000"),
            originX: "center", originY: "center", left: centerX, top: centerY,
            selectable: false, evented: false, text: "✔ " + countText,
            rectangleId: rectangle.rectangleId, isRectangleLabel: true,
            textAlign: 'center', id: labelId, isCountLabel: true
        });
        rectangle.labelText = labelText;
        rectangle.labelTextId = labelId;
        rectangle.currentCount = count;
        rectangle.set('labelTextId', labelId);
        rectangle.set('currentCount', count);
        canvas.add(labelText);
        canvas.bringToFront(labelText);
    },

    updateAngledRowGuides(canvas, start, angle, count) {
        const spacing = this.seatSpacing || 20;
        const length = (count - 1) * spacing;
        const endX = start.x + Math.cos(angle * Math.PI / 180) * length;
        const endY = start.y + Math.sin(angle * Math.PI / 180) * length;
        this.clearAlignmentGuides(canvas);
        const perpAngle = angle + 90;
        const guideLength = canvas.height;
        const startGuideX1 = start.x + Math.cos(perpAngle * Math.PI / 180) * guideLength;
        const startGuideY1 = start.y + Math.sin(perpAngle * Math.PI / 180) * guideLength;
        const startGuideX2 = start.x - Math.cos(perpAngle * Math.PI / 180) * guideLength;
        const startGuideY2 = start.y - Math.sin(perpAngle * Math.PI / 180) * guideLength;
        const endGuideX1 = endX + Math.cos(perpAngle * Math.PI / 180) * guideLength;
        const endGuideY1 = endY + Math.sin(perpAngle * Math.PI / 180) * guideLength;
        const endGuideX2 = endX - Math.cos(perpAngle * Math.PI / 180) * guideLength;
        const endGuideY2 = endY - Math.sin(perpAngle * Math.PI / 180) * guideLength;
        this.alignmentGuides.start = this.createOrUpdateGuide(canvas, this.alignmentGuides.start, startGuideX1, startGuideY1, startGuideX2, startGuideY2);
        this.alignmentGuides.end = this.createOrUpdateGuide(canvas, this.alignmentGuides.end, endGuideX1, endGuideY1, endGuideX2, endGuideY2);
    },

    snapToStraightLine(angle) {
        let normalizedAngle = ((angle % 360) + 360) % 360;
        const snapZones = [
            { center: 0, target: 0 }, { center: 180, target: 180 },
            { center: 90, target: 90 }, { center: 270, target: 270 },
            { center: 45, target: 45 }, { center: 135, target: 135 },
            { center: 225, target: 225 }, { center: 315, target: 315 }
        ];
        for (const zone of snapZones) {
            let distance = Math.abs(normalizedAngle - zone.center);
            distance = Math.min(distance, 360 - distance);
            if (distance <= this.snapThreshold) return zone.target;
        }
        return angle;
    },

    showStraightLineGuide(canvas, start, angle) {
        if (this.straightLineGuide) {
            canvas.remove(this.straightLineGuide);
            this.straightLineGuide = null;
        }
        const canvasWidth = canvas.width;
        const canvasHeight = canvas.height;
        if (angle === 0 || angle === 180) {
            this.straightLineGuide = new fabric.Line([0, start.y, canvasWidth, start.y], {
                stroke: "rgba(76, 175, 80, 0.3)", strokeWidth: 1, strokeDashArray: [3, 3],
                selectable: false, evented: false
            });
        } else if (angle === 90 || angle === 270) {
            this.straightLineGuide = new fabric.Line([start.x, 0, start.x, canvasHeight], {
                stroke: "rgba(76, 175, 80, 0.3)", strokeWidth: 1, strokeDashArray: [3, 3],
                selectable: false, evented: false
            });
        } else {
            const radians = angle * Math.PI / 180;
            let points = this.calculateLineCanvasIntersection(start, radians, canvasWidth, canvasHeight);
            if (points) {
                this.straightLineGuide = new fabric.Line([points.x1, points.y1, points.x2, points.y2], {
                    stroke: "rgba(76, 175, 80, 0.3)", strokeWidth: 1, strokeDashArray: [3, 3],
                    selectable: false, evented: false
                });
            }
        }
        if (this.straightLineGuide) {
            canvas.add(this.straightLineGuide);
            canvas.sendToBack(this.straightLineGuide);
        }
    },

    calculateLineCanvasIntersection(point, angleRad, canvasWidth, canvasHeight) {
        const m = Math.tan(angleRad);
        const b = point.y - m * point.x;
        const intersections = [];
        const yLeft = m * 0 + b;
        if (yLeft >= 0 && yLeft <= canvasHeight) intersections.push({ x: 0, y: yLeft });
        const yRight = m * canvasWidth + b;
        if (yRight >= 0 && yRight <= canvasHeight) intersections.push({ x: canvasWidth, y: yRight });
        if (m !== 0) {
            const xTop = (0 - b) / m;
            if (xTop >= 0 && xTop <= canvasWidth) intersections.push({ x: xTop, y: 0 });
        }
        if (m !== 0) {
            const xBottom = (canvasHeight - b) / m;
            if (xBottom >= 0 && xBottom <= canvasWidth) intersections.push({ x: xBottom, y: canvasHeight });
        }
        if (intersections.length >= 2) {
            return { x1: intersections[0].x, y1: intersections[0].y, x2: intersections[1].x, y2: intersections[1].y };
        }
        return null;
    },

    updateMultiRowFirstRowPreview(canvas, pointer, opt) {
        this.previewSeats.forEach(s => canvas.remove(s));
        this.previewSeats = [];
        if (this.previewLine) {
            canvas.remove(this.previewLine);
            this.previewLine = null;
        }
        if (this.straightLineGuide) {
            canvas.remove(this.straightLineGuide);
            this.straightLineGuide = null;
        }
        const dx = pointer.x - this.rowStart.x;
        const dy = pointer.y - this.rowStart.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const spacing = this.seatSpacing || 20;
        if (distance < 5) {
            canvas.renderAll();
            return;
        }
        let angle = Math.atan2(dy, dx) * (180 / Math.PI);
        const snappedAngle = this.snapToStraightLine(angle);
        const isSnapped = snappedAngle !== angle;
        if (isSnapped) {
            angle = snappedAngle;
            this.showStraightLineGuide(canvas, this.rowStart, angle);
        }
        this.rowAngle = angle;
        this.firstRowAngle = angle;
        const seatCount = Math.max(2, Math.floor(distance / spacing) + 1);
        const rowLength = (seatCount - 1) * spacing;
        const endX = this.rowStart.x + Math.cos(angle * Math.PI / 180) * rowLength;
        const endY = this.rowStart.y + Math.sin(angle * Math.PI / 180) * rowLength;
        const lineColor = isSnapped ? "#4CAF50" : "#2196F3";
        const lineDash = isSnapped ? [] : [5, 5];
        this.previewLine = new fabric.Line([this.rowStart.x, this.rowStart.y, endX, endY], {
            stroke: lineColor, strokeDashArray: lineDash, selectable: false, evented: false, strokeWidth: 2
        });
        canvas.add(this.previewLine);
        for (let i = 0; i < seatCount; i++) {
            const seatDistance = i * spacing;
            const x = this.rowStart.x + Math.cos(angle * Math.PI / 180) * seatDistance;
            const y = this.rowStart.y + Math.sin(angle * Math.PI / 180) * seatDistance;
            const seat = new fabric.Circle({
                left: x, top: y, radius: 8, fill: "white", originX: "center", originY: "center",
                selectable: false, evented: false, stroke: "black", strokeWidth: 1
            });
            seat.isPreview = true;
            this.previewSeats.push(seat);
            canvas.add(seat);
        }
        this.firstRowSeatCount = seatCount;
        this.updateAngledRowGuides(canvas, this.rowStart, angle, seatCount);
        const tooltip = document.getElementById("seatTooltip");
        if (tooltip) {
            setTimeout(() => {
                let directionText = "";
                if (Math.abs(angle) < 22.5 || Math.abs(angle - 180) < 22.5) directionText = "→ Horizontal";
                else if (Math.abs(angle - 90) < 22.5 || Math.abs(angle - 270) < 22.5) directionText = "↓ Vertical";
                else directionText = `↗ ${Math.round(angle)}°`;
                tooltip.textContent = `${seatCount} seats (${directionText})`;
                tooltip.style.left = (opt.e.clientX + 10) + "px";
                tooltip.style.top = (opt.e.clientY + 10) + "px";
                tooltip.style.display = "block";
            }, 0);
        }
        canvas.renderAll();
    },

    getAbsoluteSeatPosition(seat) {
        if (!seat) return { x: 0, y: 0 };
        try {
            const center = seat.getCenterPoint();
            return { x: center.x, y: center.y };
        } catch (e) { }
        try {
            const matrix = seat.calcTransformMatrix();
            const transformed = fabric.util.transformPoint(new fabric.Point(0, 0), matrix);
            return { x: transformed.x, y: transformed.y };
        } catch (e) { }
        return { x: seat.left || 0, y: seat.top || 0 };
    },

    updateDragGuides(canvas, firstCenterX, lastCenterX) {
        if (!this.dragGuides) this.dragGuides = {};
        const canvasTop = 0;
        const canvasBottom = canvas.getHeight();
        if (!this.dragGuides.start) {
            this.dragGuides.start = new fabric.Line([0, 0, 0, 0], {
                stroke: '#81D4FA', strokeWidth: 1, selectable: false, evented: false, strokeDashArray: [6, 4]
            });
            canvas.add(this.dragGuides.start);
        }
        this.dragGuides.start.set({ x1: firstCenterX, x2: firstCenterX, y1: canvasTop, y2: canvasBottom });
        if (!this.dragGuides.end) {
            this.dragGuides.end = new fabric.Line([0, 0, 0, 0], {
                stroke: '#81D4FA', strokeWidth: 1, selectable: false, evented: false, strokeDashArray: [6, 4]
            });
            canvas.add(this.dragGuides.end);
        }
        this.dragGuides.end.set({ x1: lastCenterX, x2: lastCenterX, y1: canvasTop, y2: canvasBottom });
        canvas.requestRenderAll();
    },

    clearDragGuides(canvas) {
        if (!this.dragGuides) return;
        if (this.dragGuides.start) {
            canvas.remove(this.dragGuides.start);
            this.dragGuides.start = null;
        }
        if (this.dragGuides.end) {
            canvas.remove(this.dragGuides.end);
            this.dragGuides.end = null;
        }
        canvas.requestRenderAll();
    },

    

    adjustRowSeats(canvasId) {
        const canvas = this.canvases[canvasId];
        const active = canvas.getActiveObject();

        if (!active) return;

        let seats = [];
        let isActiveSelection = false;

        if (active.type === "activeSelection") {
            isActiveSelection = true;
            // Get objects and their absolute positions BEFORE discarding selection
            seats = active.getObjects().filter(o => o.type === "group");
        } else if (active.type === "group") {
            seats = [active];
        } else {
            return;
        }

        const newSeatCount = parseInt(document.getElementById("txtseatcount").value);

        if (isNaN(newSeatCount) || newSeatCount <= 0) return;

        const direction = document.getElementById("ddldirection")?.value || "LTR";

        // If it's an active selection, we need to get absolute positions first
        // by calculating them from the group's transform matrix
        if (isActiveSelection) {
            // Store absolute positions for all seats
            seats.forEach(seat => {
                const matrix = seat.calcTransformMatrix();
                const point = fabric.util.transformPoint(
                    new fabric.Point(0, 0),
                    matrix
                );
                seat._absoluteLeft = point.x;
                seat._absoluteTop = point.y;
            });
        }

        // Discard active object BEFORE making changes
        canvas.discardActiveObject();

        // Now work with the seats using their absolute positions
        const rows = this.groupSeatsByRow(seats);

        isBulkAdding = true;

        Object.keys(rows).forEach(rowKey => {
            let rowSeats = rows[rowKey];

            // Sort by absolute position
            if (isActiveSelection) {
                rowSeats.sort((a, b) => a._absoluteLeft - b._absoluteLeft);
            } else {
                rowSeats.sort((a, b) => a.left - b.left);
            }

            const currentCount = rowSeats.length;

            // ==================================
            // REMOVE SEATS
            // ==================================
            if (newSeatCount < currentCount) {
                let seatsToRemove;

                if (direction === "RTL") {
                    seatsToRemove = rowSeats.slice(0, currentCount - newSeatCount);
                } else {
                    seatsToRemove = rowSeats.slice(newSeatCount);
                }

                seatsToRemove.forEach(seat => {
                    canvas.remove(seat);
                });

                return;
            }

            // ==================================
            // ADD SEATS
            // ==================================
            if (newSeatCount > currentCount) {
                const seatsNeeded = newSeatCount - currentCount;

                const firstSeat = rowSeats[0];
                const lastSeat = rowSeats[rowSeats.length - 1];

                const rowLabel = lastSeat.rowLabel || lastSeat.get("rowLabel") || "";
                const rowId = lastSeat.rowId || lastSeat.get("rowId") || "";

                // Calculate spacing from actual seat positions
                let spacing = this.seatSpacing || 22;

                if (rowSeats.length > 1) {
                    if (isActiveSelection) {
                        spacing = Math.abs(
                            rowSeats[1]._absoluteLeft - rowSeats[0]._absoluteLeft
                        );
                    } else {
                        spacing = Math.abs(rowSeats[1].left - rowSeats[0].left);
                    }
                }

                // Get the row's Y position (use absolute position if from selection)
                let rowY;
                if (isActiveSelection) {
                    rowY = firstSeat._absoluteTop;
                } else {
                    rowY = firstSeat.top;
                }

                // Determine starting X position based on direction
                let anchorX;
                if (direction === "RTL") {
                    anchorX = isActiveSelection ? firstSeat._absoluteLeft : firstSeat.left;
                } else {
                    anchorX = isActiveSelection ? lastSeat._absoluteLeft : lastSeat.left;
                }

                // Create new seats
                for (let i = 0; i < seatsNeeded; i++) {
                    let newX;

                    if (direction === "RTL") {
                        // Add seats to the left of the first seat
                        newX = anchorX - (spacing * (i + 1));
                    } else {
                        // Add seats to the right of the last seat
                        newX = anchorX + (spacing * (i + 1));
                    }

                    const seatNumber = currentCount + i + 1;
                    const seatLabel = seatNumber.toString();

                    const seatId =
                        rowLabel && rowLabel.trim() !== ""
                            ? rowLabel + seatLabel
                            : `Seat-${this.seatCounter++}`;

                    this.createSeat(
                        canvas,
                        newX,
                        rowY,
                        seatLabel,
                        seatId,
                        rowLabel,
                        rowId
                    );
                }
            }
        });

        isBulkAdding = false;

        // Clean up temporary properties
        seats.forEach(seat => {
            delete seat._absoluteLeft;
            delete seat._absoluteTop;
        });

        // Refresh canvas
        canvas.forEachObject(obj => {
            obj.setCoords();
        });

        canvas.calcOffset();
        canvas.requestRenderAll();

        saveState(canvas);
        this.showValidation(canvas);
    },

    renumberSeats(canvas, direction) {
        const allSeats = canvas.getObjects().filter(o => o.type === "group");
        const rows = this.groupSeatsByRow(allSeats);
        Object.keys(rows).forEach(rowKey => {
            let rowSeats = rows[rowKey];
            rowSeats.sort((a, b) => getSeatX(a) - getSeatX(b));
            const orderedSeats = (direction === "RTL") ? [...rowSeats].reverse() : rowSeats;
            orderedSeats.forEach((seat, index) => {
                const newLabel = (index + 1).toString();
                seat.set('seatLabel', newLabel);
                seat.seatLabel = newLabel;
                const rowLabel = seat.rowLabel || "";
                const seatId = rowLabel ? rowLabel + newLabel : newLabel;
                seat.set('seatId', seatId);
                seat.seatId = seatId;
            });
        });
    },

    fitAndCenterChart(canvas) {
        const objects = canvas.getObjects();
        if (!objects.length) return;
        const canvasWidth = canvas.getWidth();
        const canvasHeight = canvas.getHeight();
        const bounds = objects.reduce((acc, obj) => {
            const rect = obj.getBoundingRect(true, true);
            acc.left = Math.min(acc.left, rect.left);
            acc.top = Math.min(acc.top, rect.top);
            acc.right = Math.max(acc.right, rect.left + rect.width);
            acc.bottom = Math.max(acc.bottom, rect.top + rect.height);
            return acc;
        }, { left: Infinity, top: Infinity, right: -Infinity, bottom: -Infinity });
        const chartWidth = bounds.right - bounds.left;
        const chartHeight = bounds.bottom - bounds.top;
        const chartCenterX = bounds.left + chartWidth / 2;
        const chartCenterY = bounds.top + chartHeight / 2;
        const canvasCenterX = canvasWidth / 2;
        const canvasCenterY = canvasHeight / 2;
        let zoom = 1;
        if (chartWidth > canvasWidth || chartHeight > canvasHeight) {
            const scaleX = canvasWidth / chartWidth;
            const scaleY = canvasHeight / chartHeight;
            zoom = Math.min(scaleX, scaleY) * 0.9;
        }
        canvas.setZoom(zoom);
        const vp = canvas.viewportTransform;
        vp[4] = canvasCenterX - chartCenterX * zoom;
        vp[5] = canvasCenterY - chartCenterY * zoom;
        canvas.requestRenderAll();
    },

    getSnappedRowStart(pointer) {
        const base = this.lastRowPosition;
        if (!base) return pointer;
        const angleRad = base.angle * Math.PI / 180;
        const perpX = -Math.sin(angleRad);
        const perpY = Math.cos(angleRad);
        const dirX = Math.cos(angleRad);
        const dirY = Math.sin(angleRad);
        const dx = pointer.x - base.x;
        const dy = pointer.y - base.y;
        const offset = dx * perpX + dy * perpY;
        const along = dx * dirX + dy * dirY;
        const horizontalLimit = this.seatSpacing * 10;
        if (Math.abs(along) > horizontalLimit) return pointer;
        const rowIndex = Math.round(offset / this.rowGap);
        return { x: base.x + perpX * rowIndex * this.rowGap, y: base.y + perpY * rowIndex * this.rowGap };
    },

    showRowCustomizeOptions(canvasId) {
        const canvas = this.canvases[canvasId];
        const activeObject = canvas.getActiveObject();
        if (!activeObject) {
            showNotification("Please select rows first", "info");
            return;
        }
        const selectedRows = this.getSelectedRows(activeObject, canvas);
        if (selectedRows.length === 0) {
            showNotification("No rows selected. Please select seats that belong to rows.", "info");
            return;
        }
        let panel = document.getElementById("rowCustomizePanel");
        if (!panel) {
            panel = document.createElement("div");
            panel.id = "rowCustomizePanel";
            panel.style.cssText = `position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 20px rgba(0,0,0,0.15); z-index: 10000; min-width: 320px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;`;
            panel.innerHTML = `<div style="margin-bottom: 15px;"><label style="display: block; margin-bottom: 5px; font-weight: 500;">Curve Type:</label><select id="curveTypeSelect" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;"><option value="up">Curve Up (U Shape) ⌣</option><option value="down">Curve Down (∩ Shape) ⌢</option><option value="wave">Wave Pattern ~</option><option value="none">None (Straighten)</option></select></div><div style="margin-bottom: 20px;"><label style="display: block; margin-bottom: 5px; font-weight: 500;">Curve Intensity: <span id="intensityValue" style="color: #4CAF50; font-weight: bold;">50</span></label><input type="range" id="curveIntensity" min="0" max="100" value="50" style="width: 100%;"><div style="display: flex; justify-content: space-between; margin-top: 5px;"><span style="font-size: 12px; color: #666;">Gentle</span><span style="font-size: 12px; color: #666;">Extreme</span></div></div><div style="margin-bottom: 15px;"><label style="display: block; margin-bottom: 5px; font-weight: 500;">Preview:</label><div style="background: #f5f5f5; border-radius: 4px; padding: 10px; text-align: center;"><canvas id="curvePreviewCanvas" width="280" height="60" style="border: 1px solid #ddd; background: white;"></canvas></div></div><div style="display: flex; gap: 10px; justify-content: flex-end;"><button id="applyCurveBtn" style="padding: 8px 20px; background: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px;">Apply Curve</button><button id="cancelCurveBtn" style="padding: 8px 20px; background: #f44336; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px;">Cancel</button></div>`;
            document.body.appendChild(panel);
            const previewCanvas = document.getElementById("curvePreviewCanvas");
            this.drawCurvePreview(previewCanvas, "up", 50);
            const intensitySlider = document.getElementById("curveIntensity");
            const intensityValue = document.getElementById("intensityValue");
            const curveTypeSelect = document.getElementById("curveTypeSelect");
            intensitySlider.addEventListener("input", (e) => {
                const value = e.target.value;
                intensityValue.textContent = value;
                const curveType = curveTypeSelect.value;
                if (curveType !== "none") this.drawCurvePreview(previewCanvas, curveType, parseInt(value));
            });
            curveTypeSelect.addEventListener("change", (e) => {
                const curveType = e.target.value;
                const intensity = parseInt(intensitySlider.value);
                if (curveType !== "none") this.drawCurvePreview(previewCanvas, curveType, intensity);
                else this.drawStraightPreview(previewCanvas);
            });
            document.getElementById("applyCurveBtn").addEventListener("click", () => {
                const curveType = document.getElementById("curveTypeSelect").value;
                const intensity = parseInt(intensitySlider.value);
                const radius = (intensity / 100) * 80;
                if (curveType === "none") this.straightenSelectedRows(canvasId);
                else this.curveSelectedRows(canvasId, radius, curveType);
                panel.remove();
            });
            document.getElementById("cancelCurveBtn").addEventListener("click", () => panel.remove());
        }
        panel.style.display = "block";
    },

    drawCurvePreview(canvas, curveType, intensity) {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const width = canvas.width;
        const height = canvas.height;
        const centerY = height / 2;
        const radius = (intensity / 100) * 30;
        ctx.beginPath();
        ctx.strokeStyle = '#4CAF50';
        ctx.lineWidth = 2;
        if (curveType === "up") {
            for (let x = 0; x <= width; x++) {
                const t = (x / width) * 2 - 1;
                const y = centerY - radius * (1 - Math.pow(t, 2));
                if (x === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
        } else if (curveType === "down") {
            for (let x = 0; x <= width; x++) {
                const t = (x / width) * 2 - 1;
                const y = centerY + radius * (1 - Math.pow(t, 2));
                if (x === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
        } else if (curveType === "wave") {
            for (let x = 0; x <= width; x++) {
                const t = (x / width) * Math.PI * 2;
                const y = centerY + radius * Math.sin(t);
                if (x === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
        }
        ctx.stroke();
        ctx.fillStyle = '#2196F3';
        for (let x = 0; x <= width; x += width / 4) {
            const t = (x / width) * 2 - 1;
            let y;
            if (curveType === "up") y = centerY - radius * (1 - Math.pow(t, 2));
            else if (curveType === "down") y = centerY + radius * (1 - Math.pow(t, 2));
            else if (curveType === "wave") y = centerY + radius * Math.sin((x / width) * Math.PI * 2);
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, 2 * Math.PI);
            ctx.fill();
        }
    },

    drawStraightPreview(canvas) {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const width = canvas.width;
        const height = canvas.height;
        const centerY = height / 2;
        ctx.beginPath();
        ctx.strokeStyle = '#999';
        ctx.lineWidth = 2;
        ctx.moveTo(0, centerY);
        ctx.lineTo(width, centerY);
        ctx.stroke();
        ctx.fillStyle = '#999';
        for (let x = 0; x <= width; x += width / 4) {
            ctx.beginPath();
            ctx.arc(x, centerY, 3, 0, 2 * Math.PI);
            ctx.fill();
        }
    },

    getSelectedRows(activeObject, canvas) {
        let selectedSeats = [];
        if (activeObject.type === "activeSelection") selectedSeats = activeObject._objects.filter(o => o.type === "group");
        else if (activeObject.type === "group") selectedSeats = [activeObject];
        else return [];
        const rowsMap = new Map();
        selectedSeats.forEach(seat => {
            if (seat.rowId && seat.rowId !== "") {
                if (!rowsMap.has(seat.rowId)) rowsMap.set(seat.rowId, []);
                rowsMap.get(seat.rowId).push(seat);
            }
        });
        const rows = [];
        rowsMap.forEach((seats, rowId) => {
            seats.sort((a, b) => a.left - b.left);
            rows.push({ rowId: rowId, seats: seats, rowLabel: seats[0]?.rowLabel || "" });
        });
        return rows;
    },

    curveSelectedRows(canvasId, radius, curveDirection) {
        const canvas = this.canvases[canvasId];
        const activeObject = canvas.getActiveObject();
        if (!activeObject) return;
        const selectedRows = this.getSelectedRows(activeObject, canvas);
        if (selectedRows.length === 0) {
            showNotification("No valid rows selected", "info");
            return;
        }
        saveState(canvas);
        selectedRows.forEach(rowData => this.curveRow(canvas, rowData.seats, radius, curveDirection));
        canvas.renderAll();
        saveState(canvas);
        showNotification(`${selectedRows.length} row(s) curved successfully`, "success");
    },

    curveRow(canvas, seats, radius, direction) {
        if (seats.length < 2) return;
        const originalPositions = seats.map(seat => ({ seat: seat, x: seat.left, y: seat.top, originalX: seat.left, originalY: seat.top }));
        const minX = Math.min(...originalPositions.map(p => p.x));
        const maxX = Math.max(...originalPositions.map(p => p.x));
        const centerX = (minX + maxX) / 2;
        const avgY = originalPositions.reduce((sum, p) => sum + p.y, 0) / seats.length;
        const rowWidth = maxX - minX;
        const halfWidth = rowWidth / 2;
        originalPositions.forEach(position => {
            const seat = position.seat;
            const relativeX = position.x - centerX;
            const normalizedX = relativeX / halfWidth;
            let yOffset = 0;
            switch (direction) {
                case "up": yOffset = -radius * (1 - Math.pow(normalizedX, 2)); break;
                case "down": yOffset = radius * (1 - Math.pow(normalizedX, 2)); break;
                case "wave": yOffset = radius * Math.sin(normalizedX * Math.PI); break;
                default: yOffset = -radius * (1 - Math.pow(normalizedX, 2));
            }
            const newY = avgY + yOffset;
            seat.set({ left: position.x, top: newY });
            if (!seat.originalPosition) seat.originalPosition = { x: position.originalX, y: position.originalY };
        });
    },

    straightenSelectedRows(canvasId) {
        const canvas = this.canvases[canvasId];
        const activeObject = canvas.getActiveObject();
        if (!activeObject) return;
        const selectedRows = this.getSelectedRows(activeObject, canvas);
        if (selectedRows.length === 0) return;
        saveState(canvas);
        selectedRows.forEach(rowData => {
            rowData.seats.forEach(seat => {
                if (seat.originalPosition) seat.set({ left: seat.originalPosition.x, top: seat.originalPosition.y });
            });
        });
        canvas.renderAll();
        saveState(canvas);
        showNotification(`${selectedRows.length} row(s) straightened`, "success");
    },

    updateCurvedRowPreview(canvas, start, pointer, curveRadius = 30) {
        const seats = this.previewSeats;
        if (seats.length < 3) return;
        const centerX = (start.x + pointer.x) / 2;
        const rowLength = Math.abs(pointer.x - start.x);
        const halfLength = rowLength / 2;
        seats.forEach((seat, index) => {
            const t = index / (seats.length - 1);
            const x = start.x + (pointer.x - start.x) * t;
            const relativeX = (x - centerX) / halfLength;
            const yOffset = -curveRadius * (1 - Math.pow(relativeX, 2));
            const y = start.y + yOffset;
            seat.set({ left: x, top: y });
        });
        canvas.renderAll();
    },

    updateMultiRowPreviewAllDirections(canvas, pointer, opt) {
        if (!this.multiRowStartPoint) return;
        const dx = pointer.x - this.multiRowStartPoint.x;
        const dy = pointer.y - this.multiRowStartPoint.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < 5) return;
        const absDx = Math.abs(dx);
        const absDy = Math.abs(dy);
        let currentDirection;
        if (absDx > absDy * 1.5) {
            currentDirection = dx > 0 ? "right" : "left";
        } else if (absDy > absDx * 1.5) {
            currentDirection = dy > 0 ? "down" : "up";
        } else {
            currentDirection = "angled";
            this.multiRowAngle = Math.atan2(dy, dx) * (180 / Math.PI);
        }
        this.multiRowDirection = currentDirection;
        this.multiRowCurrentPoint = { x: pointer.x, y: pointer.y };
        this.clearGeneratedRows(canvas);
        const rowGap = this.rowGap || 30;
        let rowCount = 0;
        let rowPositions = [];
        const baseX = this.firstRowBaseX || this.firstRowStartX || this.rowStart.x;
        const baseY = this.firstRowBaseY || this.firstRowStartY || this.rowStart.y;
        switch (currentDirection) {
            case "down":
                rowCount = Math.floor(Math.abs(dy) / rowGap);
                for (let i = 1; i < rowCount; i++) rowPositions.push({ index: i, x: baseX, y: baseY + i * rowGap });
                break;
            case "up":
                rowCount = Math.floor(Math.abs(dy) / rowGap);
                for (let i = 1; i < rowCount; i++) rowPositions.push({ index: -i, x: baseX, y: baseY - i * rowGap });
                break;
            case "right":
                rowCount = Math.floor(Math.abs(dx) / rowGap);
                for (let i = 1; i < rowCount; i++) rowPositions.push({ index: i, x: baseX + i * rowGap, y: baseY });
                break;
            case "left":
                rowCount = Math.floor(Math.abs(dx) / rowGap);
                for (let i = 1; i < rowCount; i++) rowPositions.push({ index: -i, x: baseX - i * rowGap, y: baseY });
                break;
            case "angled":
                const angleRad = this.multiRowAngle * Math.PI / 180;
                const perpAngle = angleRad + Math.PI / 2;
                const maxDistance = Math.max(Math.abs(dx), Math.abs(dy));
                rowCount = Math.floor(maxDistance / rowGap);
                for (let i = 1; i < rowCount; i++) {
                    const offset = i * rowGap;
                    rowPositions.push({ index: i, x: baseX + Math.cos(perpAngle) * offset, y: baseY + Math.sin(perpAngle) * offset });
                }
                break;
        }
        rowPositions.forEach(pos => this.createPreviewRowAtPosition(canvas, pos.x, pos.y, pos.index, opt));
        const tooltip = document.getElementById("seatTooltip");
        if (tooltip && opt && opt.e) {
            let directionArrow = "";
            switch (currentDirection) {
                case "down": directionArrow = "↓"; break;
                case "up": directionArrow = "↑"; break;
                case "right": directionArrow = "→"; break;
                case "left": directionArrow = "←"; break;
                case "angled": directionArrow = "↗"; break;
            }
            tooltip.textContent = `${rowCount} row(s) ${directionArrow}`;
            tooltip.style.left = (opt.e.clientX + 10) + "px";
            tooltip.style.top = (opt.e.clientY + 10) + "px";
            tooltip.style.display = "block";
        }
        canvas.renderAll();
    },

    createPreviewRowAtPosition(canvas, startX, startY, rowIndex, opt) {
        const spacing = this.seatSpacing || 22;
        const seatCount = this.firstRowSeatCount;
        const angle = this.firstRowAngle || this.rowAngle || 0;
        if (seatCount === 0) return;
        for (let i = 0; i < seatCount; i++) {
            const seatDistance = i * spacing;
            const x = startX + Math.cos(angle * Math.PI / 180) * seatDistance;
            const y = startY + Math.sin(angle * Math.PI / 180) * seatDistance;
            const seat = new fabric.Circle({
                left: x, top: y, radius: 8, fill: "rgba(255, 255, 255, 0.7)",
                originX: "center", originY: "center", selectable: false, evented: false,
                stroke: "#4c7daf", strokeWidth: 1
            });
            seat.isPreviewRow = true;
            seat.rowIndex = rowIndex;
            seat.seatIndex = i;
            this.previewSeats.push(seat);
            canvas.add(seat);
        }
        const endX = startX + Math.cos(angle * Math.PI / 180) * ((seatCount - 1) * spacing);
        const endY = startY + Math.sin(angle * Math.PI / 180) * ((seatCount - 1) * spacing);
        const line = new fabric.Line([startX, startY, endX, endY], {
            stroke: "#4c7daf", strokeDashArray: [5, 5], strokeWidth: 1,
            selectable: false, evented: false, opacity: 0.7
        });
        line.isPreviewRow = true;
        line.rowIndex = rowIndex;
        this.previewSeats.push(line);
        canvas.add(line);
        if (!this.multiRowPreviewRows) this.multiRowPreviewRows = [];
        this.multiRowPreviewRows.push({ rowIndex: rowIndex, startX: startX, startY: startY, line: line });
    },

    createActualRowsFromPreviewsAllDirections(canvas) {
        if (this.firstRowSeatCount === 0) return;
        if (!this.multiRowPreviewRows || this.multiRowPreviewRows.length === 0) return;
        const spacing = this.seatSpacing || 22;
        const angle = this.firstRowAngle || 0;
        isBulkAdding = true;
        const sortedRows = [...this.multiRowPreviewRows].sort((a, b) => a.rowIndex - b.rowIndex);
        sortedRows.forEach(rowData => {
            const rowLabel = "";
            const rowId = `row-${rowLabel}-${Date.now()}-${rowData.rowIndex}`;
            for (let i = 0; i < this.firstRowSeatCount; i++) {
                const seatDistance = i * spacing;
                const x = rowData.startX + Math.cos(angle * Math.PI / 180) * seatDistance;
                const y = rowData.startY + Math.sin(angle * Math.PI / 180) * seatDistance;
                const seatLabel = (i + 1).toString();
                const seatId = rowLabel ? `${rowLabel}${seatLabel}` : `Seat-${this.seatCounter++}`;
                this.createSeat(canvas, x, y, seatLabel, seatId, rowLabel, rowId);
            }
            this.autoIncrementRowLabel();
        });
        isBulkAdding = false;
        const lastRow = sortedRows[sortedRows.length - 1];
        if (lastRow) this.lastRowPosition = { x: lastRow.startX, y: lastRow.startY, angle: angle };
        this.multiRowPreviewRows = [];
        saveState(canvas);
    },

    getDirectionFromAngle(angle) {
        const normalized = ((angle % 360) + 360) % 360;
        if (normalized >= 315 || normalized < 45) return "right";
        if (normalized >= 45 && normalized < 135) return "down";
        if (normalized >= 135 && normalized < 225) return "left";
        return "up";
    },

    getRowAngle(rowSeats) {
        if (rowSeats.length < 2) return 0;

        const p1 = getAbsolutePosition(rowSeats[0]);
        const p2 = getAbsolutePosition(rowSeats[rowSeats.length - 1]);

        const dx = p2.x - p1.x;
        const dy = p2.y - p1.y;

        return Math.atan2(dy, dx) * (180 / Math.PI);
    },

    getPerpendicularLabelPosition(anchorPos, angle, direction, spacing = 25) {
        const angleRad = angle * Math.PI / 180;

        // perpendicular vector
        let perpX = -Math.sin(angleRad);
        let perpY = Math.cos(angleRad);

        // flip side for RTL
        if (direction === "RTL") {
            perpX *= -1;
            perpY *= -1;
        }

        return {
            x: anchorPos.x + perpX * spacing,
            y: anchorPos.y + perpY * spacing
        };
    }
};

async function loadUserChart(json, seatjson) {
    const layoutJson = json;
    if (!json) return;
    fabricInterop.initCanvas("userCanvas");
    fabricInterop.loadLayout("userCanvas", layoutJson);
    fabricInterop.enableUserMode("userCanvas", seatjson, "2");
}

document.addEventListener("keydown", (e) => {
    if (e.key === "Delete") {
        for (const id in window.fabricInterop.canvases) {
            const canvas = window.fabricInterop.canvases[id];
            if (canvas && canvas.getActiveObjects().length > 0) {
                window.fabricInterop.deleteSelected(id);
                fabricInterop.disableValidation();
            }
        }
    }
});

function generateHoldToken() {
    if (window.crypto && crypto.randomUUID) {
        return crypto.randomUUID();
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
}

function sendSelectedSeatsToParent(selectedSeats) {
    window.parent.postMessage({ type: "seatsSelected", seats: selectedSeats }, "*");
}

window.setGlobalPriceList = function (priceList) {
    console.log("Price list received in Blazor:", priceList);
    window.globalPriceList = priceList;
};

function showTooltip(x, y, htmlContent) {
    let tip = document.getElementById("seatTooltip");
    if (!tip) {
        tip = document.createElement("div");
        tip.id = "seatTooltip";
        tip.style.position = "fixed";
        tip.style.background = "#000";
        tip.style.color = "#fff";
        tip.style.padding = "6px 10px";
        tip.style.borderRadius = "4px";
        tip.style.fontSize = "12px";
        tip.style.pointerEvents = "none";
        tip.style.zIndex = "9999";
        tip.style.boxShadow = "0 2px 8px rgba(0,0,0,0.3)";
        tip.style.display = "none";
        document.body.appendChild(tip);
    }
    tip.innerHTML = htmlContent;
    tip.style.left = (x + 10) + "px";
    tip.style.top = (y + 10) + "px";
    tip.style.display = "block";
}

function hideTooltip() {
    const tip = document.getElementById("seatTooltip");
    if (tip) tip.style.display = "none";
}

function editCategoryName() {
    var txtcat = document.getElementById("txtcat");
    var lblcat = document.getElementById("lblcat");
    lblcat.style.display = "none";
    txtcat.style.display = "block";
}

function deleteCategory(id) {
    id.style.display = "none";
    var catname = id.querySelector(".cat-name");
    catname.innerText = "";
    catname.value = "";
}

function editCategory(id) {
    lblcat = document.getElementById("lblcat_" + id);
    lblcat.style.display = "none";
    lblcat.innerText = "";
    var txtcat = document.getElementById("txtcat_" + id);
    txtcat.style.display = "inline-flex";
}

function GetCatname() {
    debugger;
    const rows = document.querySelectorAll(".category-row");
    let list = [];
    let colorlist = [];
    rows.forEach(row => {
        var name = "";
        name = row.querySelector(".cat-name").innerText;
        if (name == "" || name == undefined) {
            name = row.querySelector(".cat-name").value;
        }
        const color = row.querySelector(".cat-color").value;
        if (name !== "" && name != undefined) {
            if (!colorlist.includes(color)) {
                colorlist.push(color);
                list.push({ category: name, color: color });
            }
            else {
                showNotification("Please select different color");
            }
        }
        else {
            showNotification("Please enter category name");
        }
    });
    if (list.length > 0) {
        dotNetHelper.invokeMethodAsync("SaveCategory", JSON.stringify(list));
    } 
}

function showSuccess() {
    var successmodal = document.getElementById("successModal");
    if (successmodal != undefined && successmodal != null) {
        document.getElementById("successModal").style.display = "flex";
    }
}

function closeSuccess() {
    document.getElementById("successModal").style.display = "none";
}

function saveState(canvas) {
    fabricInterop.clearPreviewLines(canvas);
    fabricInterop.clearAlignmentGuides(canvas);
    fabricInterop.clearRowGuide(canvas);
    if (this.hoverStartGuide) {
        canvas.remove(this.hoverStartGuide);
        this.hoverStartGuide = null;
    }
    if (isLoading) return;
    const objects = canvas.getObjects();
    if (objects.length === 0) return;
    const json = canvas.toJSON([
        'objectType', 'seatLabel', 'seatId', 'categoryId', 'categoryName', 'seatType', 'holdToken',
        'rowLabel', 'isRowLabel', 'seatStatus', 'createdBy', 'rectangleId', 'rectangleLabel', 'isRectangleLabel'
    ]);
    undoStack.push(JSON.stringify(json));
    redoStack = [];
}

function loadState(state) {
    if (!state) return;
    const canvas = window.fabricInterop.canvases["seatCanvas"];
    if (!canvas) return;
    isLoading = true;
    canvas.clear();
    try {
        const json = JSON.parse(state);
        if (json.objects && Array.isArray(json.objects)) {
            json.objects.forEach((objData) => {
                if (objData.objectType === 'rectangle') {
                    fabricInterop.recreateRectangleFromData(canvas, objData);
                } else if (objData.type === "group" && objData.seatId) {
                    fabricInterop.recreateSeatFromData(canvas, objData);
                } else if (objData.type === "text" || objData.type === "i-text") {
                    if (objData.isRowLabel === true) {
                        const textValue = objData.text || objData.rowLabel || "";
                        const rowText = new fabric.Text(textValue, {
                            left: objData.left || 0, top: objData.top || 0,
                            fontSize: objData.fontSize || 14, fontWeight: objData.fontWeight || "normal",
                            fill: objData.fill || "black", originX: objData.originX || "center",
                            originY: objData.originY || "center", hasControls: false,
                            selectable: false, evented: false, isRowLabel: true,
                            rowLabel: objData.rowLabel || textValue
                        });
                        rowText.set('isRowLabel', true);
                        rowText.set('rowLabel', rowText.rowLabel);
                        canvas.add(rowText);
                    } else {
                        const text = new fabric.Text(objData.text || "", {
                            left: objData.left || 0, top: objData.top || 0,
                            fontSize: objData.fontSize || 12, fill: objData.fill || "black",
                            selectable: true
                        });
                        canvas.add(text);
                    }
                }
            });
        }
    } catch (error) {
        console.error("Error parsing state JSON:", error);
    }
    canvas.renderAll();
    isLoading = false;
}

function undo() {
    redoStack.push(undoStack.pop());
    const previous = undoStack[undoStack.length - 1];
    loadState(previous);
}

function redo() {
    if (redoStack.length === 0) return;
    const nextState = redoStack.pop();
    undoStack.push(nextState);
    loadState(nextState);
}

function getAbsolutePosition(obj) {
    const matrix = obj.calcTransformMatrix();
    const pos = new fabric.Point(0, 0);
    const transformed = fabric.util.transformPoint(pos, matrix);
    return transformed;
}

function getDirection(dx, dy) {
    if (Math.abs(dx) > Math.abs(dy)) {
        return dx >= 0 ? "right" : "left";
    } else {
        return dy >= 0 ? "down" : "up";
    }
}

function previewHorizontalSegment(dx, dy) {
    const dir = dx >= 0 ? 1 : -1;
    const seatCount = Math.floor(Math.abs(dx) / (seatSize + seatGap));
    for (let i = 0; i < seatCount; i++) {
        const seat = createPreviewSeat(startX + dir * (i + 1) * (seatSize + seatGap), startY);
        previewseats.push(seat);
        canvas.add(seat);
    }
}

function previewVerticalSegment(dx, dy) {
    const dir = dy >= 0 ? 1 : -1;
    const seatCount = Math.floor(Math.abs(dy) / (seatSize + seatGap));
    for (let i = 0; i < seatCount; i++) {
        const seat = createPreviewSeat(startX, startY + dir * (i + 1) * (seatSize + seatGap));
        previewseats.push(seat);
        canvas.add(seat);
    }
}

function finalizeSegment() {
    if (previewseats.length === 0) return;
    previewseats.forEach(p => {
        const seat = new fabric.Circle({
            left: p.left, top: p.top, radius: 8, fill: "white",
            originX: "center", originY: "center", selectable: true, evented: true,
            stroke: "black", strokeWidth: 1, objectType: "seat"
        });
        canvas.add(seat);
        canvas.remove(p);
    });
    previewseats = [];
    canvas.renderAll();
}

function clearPreview() {
    if (window.fabricInterop.mode === "segmentRow" && segmentRowPreviewMode && previewseats.length > 0) {
        console.log("Skipping clear - preview mode active with seats");
        return;
    }
    previewseats.forEach(s => {
        if (s && s.canvas === canvas) canvas.remove(s);
    });
    previewseats = [];
}

function createPreviewSeat(x, y) {
    return new fabric.Circle({
        left: x, top: y, radius: 8, fill: "rgba(255, 255, 255, 0.7)",
        originX: "center", originY: "center", selectable: false, evented: false, stroke: "blue"
    });
}

function createDynamicPreview(dx, dy, isTemporary, direction) {
    if (!segmentActive) return;
    if (direction === "horizontal") {
        const dirX = dx > 0 ? 1 : -1;
        const seatCount = Math.max(1, Math.floor(Math.abs(dx) / (seatSize + seatGap)));
        for (let i = 0; i < seatCount; i++) {
            const seat = createPreviewSeat(startX + dirX * i * (seatSize + seatGap), startY);
            if (isTemporary) currentRowPreview.push(seat);
            else previewseats.push(seat);
            canvas.add(seat);
        }
    } else if (direction === "vertical") {
        const dirY = dy > 0 ? 1 : -1;
        const seatCount = Math.max(1, Math.floor(Math.abs(dy) / (seatSize + seatGap)));
        for (let i = 0; i < seatCount; i++) {
            const seat = createPreviewSeat(startX, startY + dirY * i * (seatSize + seatGap));
            if (isTemporary) currentRowPreview.push(seat);
            else previewseats.push(seat);
            canvas.add(seat);
        }
    }
    canvas.renderAll();
}

function clearSegmentRowPreviews() {
    if (window.fabricInterop.mode !== "segmentRow") {
        clearPreview();
        previewseats = [];
        segmentActive = false;
        segmentRowPreviewMode = false;
        segmentRowFinalized = false;
        direction = null;
    }
}

function resetSegmentRowState() {
    if (window.fabricInterop.mode !== "segmentRow") {
        clearPreview();
        previewseats = [];
        segmentActive = false;
        segmentRowPreviewMode = false;
        segmentRowFinalized = false;
        direction = null;
    }
}

function getContrastColor(hexColor) {
    if (hexColor == undefined || hexColor == "") return 'black';
    const r = parseInt(hexColor.slice(1, 3), 16);
    const g = parseInt(hexColor.slice(3, 5), 16);
    const b = parseInt(hexColor.slice(5, 7), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.5 ? 'black' : 'white';
}

function closeSeatPopup() {
    document.getElementById("seatAdjustmentPopup").style.display = "none";
    if (window.fabricInterop) {
        window.fabricInterop.selectedRectangle = null;
        window.fabricInterop.selectedCanvasId = null;
    }
}

document.addEventListener('keydown', (e) => {
    if (e.key === 'Shift' && window.fabricInterop.mode === 'row' && window.fabricInterop.isDrawingRow) {
        window.fabricInterop.isRotatingRow = true;
        const canvas = document.getElementById('seatCanvas');
        if (canvas) canvas.style.cursor = 'crosshair';
    }
});

document.addEventListener('keyup', (e) => {
    if (e.key === 'Shift' && window.fabricInterop.mode === 'row') {
        window.fabricInterop.isRotatingRow = false;
        const canvas = document.getElementById('seatCanvas');
        if (canvas) canvas.style.cursor = 'default';
    }
});

function zoomIn() {
    let zoom = canvas.getZoom();
    zoom *= 1.1;
    if (zoom > 3) zoom = 3;
    canvas.setZoom(zoom);
    canvas.requestRenderAll();
}

function zoomOut() {
    let zoom = canvas.getZoom();
    zoom *= 0.9;
    if (zoom < 0.5) zoom = 0.5;
    canvas.setZoom(zoom);
    canvas.requestRenderAll();
}

function resetZoom() {
    canvas.setZoom(1);
    canvas.viewportTransform = [1, 0, 0, 1, 0, 0];
    canvas.renderAll();
}

function IncrementClick() {
    var txtcapacity = document.getElementById("txtcapacity");
    var count = txtcapacity.value;
    txtcapacity.value = parseInt(count) + 1;
}

function DecrementClick() {
    var txtcapacity = document.getElementById("txtcapacity");
    var count = txtcapacity.value;
    if (parseInt(count) > 0) txtcapacity.value = parseInt(count) - 1;
}

function drawGuideLines(direction, dx, dy) {
    if (guideLine && canvas.contains(guideLine)) canvas.remove(guideLine);
    if (crossGuideLine && canvas.contains(crossGuideLine)) canvas.remove(crossGuideLine);
    const endX = startX + dx;
    const endY = startY + dy;
    if (direction === "horizontal") {
        guideLine = new fabric.Line([startX, startY, endX, startY], {
            stroke: "#00AEEF", strokeDashArray: [5, 5], selectable: false, evented: false
        });
        crossGuideLine = new fabric.Line([startX, startY - 50, startX, startY + 50], {
            stroke: "#CCCCCC", strokeDashArray: [2, 4], selectable: false, evented: false
        });
    } else {
        guideLine = new fabric.Line([startX, startY, startX, endY], {
            stroke: "#00AEEF", strokeDashArray: [5, 5], selectable: false, evented: false
        });
        crossGuideLine = new fabric.Line([startX - 50, startY, startX + 50, startY], {
            stroke: "#CCCCCC", strokeDashArray: [2, 4], selectable: false, evented: false
        });
    }
    canvas.add(guideLine);
    canvas.add(crossGuideLine);
    canvas.bringToFront(guideLine);
    canvas.bringToFront(crossGuideLine);
}

function saveHoldToken(chartId, selectedSeats, holdToken) {
    const url = `https://localhost:7203/api/chart/Update?chartId=${chartId}&seats=${selectedSeats}&holdToken=${holdToken}`;
    fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chartId: chartId, seats: selectedSeats, holdtoken: holdToken })
    }).then(res => res.json()).then(data => console.log("Saved:")).catch(err => console.error("Error:", err));
}

function showNotification(message, type = 'info', title = 'Notification') {
    const existingModal = document.getElementById('custom-notification-modal');
    if (existingModal) existingModal.remove();
    const modal = document.createElement('div');
    modal.id = 'custom-notification-modal';
    modal.style.cssText = `position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); display: flex; justify-content: center; align-items: center; z-index: 10001; animation: fadeIn 0.3s ease;`;
    const icons = { success: '✓', error: '✗', info: 'ℹ', warning: '⚠' };
    const icon = icons[type] || icons.info;
    const headerColors = { success: '#4caf50', error: '#f44336', info: '#2196f3', warning: '#ff9800' };
    const color = headerColors[type] || headerColors.info;
    const modalContent = document.createElement('div');
    modalContent.style.cssText = `background: white; border-radius: 12px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2); width: 400px; max-width: 90%; animation: scaleIn 0.3s ease; overflow: hidden;`;
    modalContent.innerHTML = `<div style="padding: 24px 20px 20px; text-align: center;"><div style="width: 60px; height: 60px; background: ${color}20; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 16px;"><span style="font-size: 32px; color: ${color}; font-weight: bold;">${icon}</span></div><p style="margin: 0 0 20px 0; color: #666; font-size: 16px; line-height: 1.5;">${message}</p><button id="modal-ok-btn" style="background: ${color}; color: white; border: none; padding: 10px 32px; border-radius: 6px; font-size: 14px; font-weight: 500; cursor: pointer; transition: transform 0.2s, opacity 0.2s; min-width: 120px;">OK</button></div>`;
    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    addModalStyles();
    const okButton = modalContent.querySelector('#modal-ok-btn');
    okButton.onclick = () => closeModal();
    okButton.onmouseenter = () => { okButton.style.transform = 'scale(1.02)'; okButton.style.opacity = '0.9'; };
    okButton.onmouseleave = () => { okButton.style.transform = 'scale(1)'; okButton.style.opacity = '1'; };
    modal.onclick = (e) => { if (e.target === modal) closeModal(); };
    const handleEsc = (e) => { if (e.key === 'Escape') { closeModal(); document.removeEventListener('keydown', handleEsc); } };
    document.addEventListener('keydown', handleEsc);
    function closeModal() {
        modal.style.animation = 'fadeOut 0.2s ease';
        setTimeout(() => { modal.remove(); document.removeEventListener('keydown', handleEsc); }, 200);
    }
}

function addModalStyles() {
    if (!document.querySelector('#modal-styles')) {
        const style = document.createElement('style');
        style.id = 'modal-styles';
        style.textContent = `@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } } @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } } @keyframes scaleIn { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }`;
        document.head.appendChild(style);
    }
}

function safeExecute(fn, errorMessage) {
    try {
        return fn();
    } catch (error) {
        console.error(errorMessage, error);
        showNotification(errorMessage, 'error');
        if (window.errorTracking) window.errorTracking.captureException(error);
        return null;
    }
}

function getSeatX(seat) {
    return seat.getBoundingRect(true, true).left;
}

function setDotNetReference(ref) {
    dotNetHelper = ref;
}

function initCustomizeButton() {
    const customizeBtn = document.getElementById("btnCustomizeRows");
    if (customizeBtn) {
        customizeBtn.addEventListener("click", () => {
            if (window.fabricInterop && window.fabricInterop.mode === "select") {
                fabricInterop.showRowCustomizeOptions("seatCanvas");
            } else {
                showNotification("Please enter select mode first", "info");
            }
        });
    }
}

